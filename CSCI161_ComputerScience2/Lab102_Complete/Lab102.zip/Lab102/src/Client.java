/**
 * This class, Client, uses the Scores class to create a
 * list of integers that a number of methods are applied too.
 * The Random class is imported to generate random ints.
 * 
 * @author dylca
 */

import java.util.Random;

public class Client {
 
    public static void main(String[] args){
        
        Scores Main = new Scores(100);
        Random rand = new Random();
        
        //This loop fills the list with random numbers from -100 to 100.
        for(int i = 0; i<100; i++){
            
            Main.add(rand.nextInt(201) - 100); 
        } 
            //Printing the contents of the bag.
            System.out.println( Main.toString() );
            
            
            //Adding 86 to the end of the list.
            Main.add(86);
            
            
            //Printing size of bag.
            System.out.println("Current size of the object:  " + Main.getCurrentSize());
            
            
            //Randomly removing a number from the bag.
            Main.remove();
            
            
            int picked = Main.get(75);
            
            System.out.println("\nThe frequency of the number that is in the 75th position (which is: " + picked + ") is:  " + Main.getFrequencyOf(picked)  );
            
            
            //The picked number is removed.
            Main.remove( picked );
            
            
            //Should be one less since picked was removed.
            System.out.println("The frequency that the number occured is now:  " + Main.getFrequencyOf(picked) );
            
            
            //Prints the frequency of 86.
           System.out.println("The frequency of 86 occuring is:  " + Main.getFrequencyOf(86) );
            
           
           //Returns true or false if the array contains 86. 
           System.out.println( Main.contains(86) );
        }
         
    }