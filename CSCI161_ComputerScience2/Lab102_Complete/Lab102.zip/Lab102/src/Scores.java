
/**
 * This class, Scores, implements the Bag interface.
 * It implements all the methods that the Bag interface has.
 * It keeps track of the numbers in the Bag with count, and stores them into an int array, list.
 * The Random class is imported to generate random ints.
 * 
 * @author dylca
 */

import java.util.Random;



public class Scores implements Bag {
    
   private int[] list, temp;
   private int count = 0;
 
   
   //Default Constructor
   public Scores(){
       
     list = new int[50];
       
   }
    
   //Overload Constructor
   public Scores(int arrayLength){
       
     list = new int[arrayLength];
     
   } 
    
    
   
   
/**
 * getCurrentSize returns the value of count.
 * @return 
 */
   public int getCurrentSize(){
       
       return count;
   }
    
    
   
   /**
    * isEmpty returns true if the list is empty, and false if it isn't.
    * @return 
    */
   public boolean isEmpty(){
       
      if (count == 0)
          return true;
      else
          return false;
      
    }
   
  
   
   /**
    * clear sets all the values of list to zero.
    */
   public void clear(){
       
       for (; count>=0; count-- ){      
          
           list[count] = 0;   
       }  
       
       count = 0;
   }
   
   
   
   /**
    * add adds a number to the list, unless
    * the next number would be outside the array.
    * In this case, it recreates the array double its size.
    *     * @param num 
    */
   public void add(int num){
      
      
       if (count == list.length){ 
         
            temp = new int[ 2* list.length ];
          
          //Copying list into temp  
         for(int k = 0; k<count; k++){ 
            
            temp[k] = list[k];
           }
          
         //Assigning reference temp to list
          list = temp; 
          
          //Setting temp equal to null
          temp = null;  
         }
       
       
     list[count] = num;
     
     
     count++;
     
   }

   

   /**
    * getFrequencyOf is passed an integer and 
    * returns the number of times that number is present in the list.
    * @param num
    * @return 
    */
   public int getFrequencyOf(int num){
       
      int frequency = 0;
       
       for (int i = 0; i<count; i++){
           
           if(list[i] == num)
               frequency++;
           
       }
       
       return frequency;  
   }

   
   
   /**
    * contains is passed and integer, and if that value is found within
    * the list, it will return true, if not, false.
    * @param num
    * @return 
    */
   public boolean contains(int num){
       
       for (int i = 0; i<count; i++){
           
           if(list[i] == num)
               return true;
           
        }
       return false;
   }
   
   
   

    /**
     * remove(int num) is passed an integer, and removes it from the list.
     * @param num 
     */
    public void remove(int num){
    
     for (int i = 0; i<count; i++){
           
           if(list[i] == num){
            
               for(; i<count; i++){        //shifts everything to the left
                   
                   list[i] = list[i+1];
               }
                
               list[count] = 0;
               
               break;                  
           }   
       }   
    
     count--;
}
    
    
    
    /**
     * remove() removes a random number from the list. 
     */
    public void remove(){
        
        Random rand = new Random();
        
        int random = rand.nextInt(count); 
        
        
       //Removing the number at the index
       for(; random<(count-1); random++){     
                   
            list[random] = list[random+1];
        }
       
       count--;
        
    }
    
    
    
    /**
     * get is passed an integer, and returns the integer at that
     * location, not that index. (The ith position).
     * @param i
     * @return 
     */
   public int get(int i){
       
       i--;
       return list[i];
   }

   
   /**
    * toString prints all the contents of the Scores class.
    * Which includes: the class name, the count, and the list of numbers.
    * @return 
    */
   public String toString(){      
       
       String numbersInBag = "";
       
       for(int i = 0; i<count; i++){
           
           numbersInBag = numbersInBag +  list[i] + " ";
           
       }
       
       
           
       return getClass().getName() + ":" + count + ":" + numbersInBag;   
   }
   
   
   /**
    * equals is passed an object and tests if it is equal
    * to the list from the scores class.
    * @param o
    * @return 
    */
   public boolean equals( Object o ){
       
       Scores s = (Scores) o;
       
       for(int i = 0; i<count; i++){
           
           if(list[i] != s.list[i]){
               return false;
           }
       }
       
       return true; 
   
   }
   
}