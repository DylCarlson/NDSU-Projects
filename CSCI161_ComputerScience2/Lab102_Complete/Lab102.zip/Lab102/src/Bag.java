
/**
 * This interface, Bag, contains all the method signatures that are
 * implemented into Scores.
 * 
 * @author dylca
 */

public interface Bag {
    
   /**
    * getCurrentSize returns the value of count.
    * @return 
    */
   int getCurrentSize();
   
   /**
    * isEmpty returns true if the list is empty, and false if it isn't.
    * @return 
    */
   boolean isEmpty();
   
   /**
    * clear sets all the values of list to zero.
    */
   void clear();   
   
   /**
    * add adds a number to the list, unless
    * the next number would be outside the array.
    * In this case, it recreates the array double its size.
    *     * @param num 
    */
   void add(int num);
   
   
   /**
    * getFrequencyOf is passed an integer and 
    * returns the number of times that number is present in the list.
    * @param num
    * @return 
    */
   int getFrequencyOf(int num);
   
   /**
    * contains is passed and integer, and if that value is found within
    * the list, it will return true, if not, false.
    * @param num
    * @return 
    */
   boolean contains(int num);
   
   /**
     * remove(int num) is passed an integer, and removes it from the list.
     * @param num 
     */
   void remove(int num);
   
   /**
     * remove() removes a random number from the list. 
     */
   void remove();
   
   /**
    * toString prints all the contents of the Scores class.
    * Which includes: the class name, the count, and the list of numbers.
    * @return 
    */
   String toString();
   

   /**
    * equals is passed an object and tests if it is equal
    * to the list from the scores class.
    * @param o
    * @return 
    */
    boolean equals(Object o); 
}
