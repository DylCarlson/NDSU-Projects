/**
 * This client class implements the hashCode cyclic-shift
 * computation described in the textbook. It includes the main method
 * calling the hashCode method on 3 similar strings.
 * 
 * @author dylca
 */

public class Client {

    
    public static void main(String[] args) {
        
        String a = "POTS";
        String b = "STOP";
        String c = "TOPS";
        
        
        hashCode(a);
        hashCode(b);
        hashCode(c);
        
        
    }
    
    /**
     * hashCode is passed a String and walks step by step
     * how it computes the hashCode using a cyclic-shift.
     * 
     * @param s
     * @return 
     */
    public static int hashCode(String s){
        
        System.out.println("---------------------------------\n"+s);
        
        int h = 0;
        for(int i = 0; i < s.length(); i++){
            
            System.out.print("\nEntering hashCode, pass " + i);
            System.out.printf( "    %32s \n", String.format("%32s", Integer.toBinaryString(h)).replace(" ", "0"));
            
            System.out.print("\nhashCode <<5 ");
            System.out.printf( "                %32s \n", String.format("%32s", Integer.toBinaryString(h<<5)).replace(" ", "0"));
            
            
            System.out.print("hashCode >>>27 ");
            System.out.printf( "              %32s \n", String.format("%32s", Integer.toBinaryString(h>>>27)).replace(" ", "0"));
            
            h = (h << 5) | (h >>> 27);      // 5-bit cyclic shift of the runing sum
            
            System.out.print("hashCode <<5 | >>>27 ");
            System.out.printf( "        %32s \n", String.format("%32s", Integer.toBinaryString(h)).replace(" ", "0"));
            
            h += (int) s.charAt(i);         // add in next character
            
            System.out.print("\nAdding character "+ s.charAt(i));
            System.out.printf( "           %32s \n", String.format("%32s", Integer.toBinaryString( (int) s.charAt(i) )).replace(" ", "0") );
            
            System.out.print("Exiting hashCode");
            System.out.printf( "             %32s \n", String.format("%32s", Integer.toBinaryString(h)).replace(" ", "0"));
        }
        
        System.out.print("\nhash code for " +s+ " is ");
        System.out.printf( "       %32s \n", String.format("%32s", Integer.toBinaryString(h)).replace(" ", "0"));
        
        return h;
        
    }
    
}
