
/**
 * This is a comparator that implements the Comparator interface and
 * compares integers.
 * @author dylca
 */

public class IntegerComparator implements Comparator<Integer> {
    
    @Override
    public int compare(Integer a, Integer b){
        
        if(a > b) return 1;
        
        else if(a < b) return -1;
        
        else return 0;
        
    }
}
