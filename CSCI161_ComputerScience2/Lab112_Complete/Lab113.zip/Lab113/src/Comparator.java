/**
 * Data Structures & Algorithms 6th Edition
 * Goodrick, Tamassia, Goldwasser
 * Page 363
 * 
 * An implementation of the Comparator interface.
 */

public interface Comparator<A> {
    
   int compare(A a, A b);
   
}
