/**
 * This client class makes a list of ten people with random lucky numbers.
 * It uses three Iterators to traverse the list and print them out
 * in their respective categories.
 * @author dylca
 */

public class Client {
    
    
    public static void main(String[] args){
    LuckyNumberList L = new LuckyNumberList();
    
    LuckyNumber p1 = new LuckyNumber("Bob");
    LuckyNumber p2 = new LuckyNumber("Dylan");
    LuckyNumber p3 = new LuckyNumber("Tom");
    LuckyNumber p4 = new LuckyNumber("Amie");
    LuckyNumber p5 = new LuckyNumber("Joel");
    LuckyNumber p6 = new LuckyNumber("Eric");
    LuckyNumber p7 = new LuckyNumber("Jim");
    LuckyNumber p8 = new LuckyNumber("Ron");
    LuckyNumber p9 = new LuckyNumber("Joe");
    LuckyNumber p10 = new LuckyNumber("Dustin");
    
   
    L.addLuckyNumber(p1);
    L.addLuckyNumber(p2);
    L.addLuckyNumber(p3);
    L.addLuckyNumber(p4);
    L.addLuckyNumber(p5);
    L.addLuckyNumber(p6);
    L.addLuckyNumber(p7);
    L.addLuckyNumber(p8);
    L.addLuckyNumber(p9);
    L.addLuckyNumber(p10);
    
        
    
    /**
     * The following code is copied from the alphabet client class
     * but modified for this client and classes.
     */
    Iterator<Position<LuckyNumber>> NumberIterator = L.positions().iterator();
       
    System.out.print("=====Using NumberIterator===== \n");
    while ( NumberIterator.hasNext() ){
         LuckyNumber element = NumberIterator.next().getElement();
        System.out.printf( "%-10s %-2d %-8s %-10s ", element.getName(), element.getLuckyNumber(), isEven(element), isPrime(element) );
        System.out.print( "\n" );
    }
        
    System.out.print( "\n\n" );
    
    
    Iterator<Position<LuckyNumber>> EvenNumberIterator = L.evenPositions().iterator();
    
    System.out.print("=====Using EvenNumberIterator===== \n");
    while ( EvenNumberIterator.hasNext() ){
        LuckyNumber element = EvenNumberIterator.next().getElement();
        System.out.printf( "%-10s %-2d %-8s %-10s ", element.getName(), element.getLuckyNumber(), isEven(element), isPrime(element) );
        System.out.print( "\n" );
        
    }
        
    System.out.print( "\n\n" );
    
    Iterator<Position<LuckyNumber>> PrimeNumberIterator = L.primePositions().iterator();
    
    System.out.print("=====Using PrimeNumberIterator===== \n");
    while ( PrimeNumberIterator.hasNext() ){
        LuckyNumber element = PrimeNumberIterator.next().getElement();
        System.out.printf( "%-10s %-2d %-8s %-10s ", element.getName(), element.getLuckyNumber(), isEven(element), isPrime(element) );
        System.out.print( "\n" );
        
    }
    
   }   
   
    /**
     * isEven is passed a LuckyNumber element and returns whether
     * it is even or odd.
     * @param e
     * @return 
     */
    public static String isEven(LuckyNumber e){
        
       int n;
        n = e.getLuckyNumber();
        
        if(n%2 == 0)
            return "Even";
        else
            return "Odd";
    }
    
    /**
     * isPrime is passed a LuckyNumber element and returns whether
     * it is prime or not prime.
     * @param e
     * @return 
     */
    public static String isPrime(LuckyNumber e){
        
        int n;
        n = e.getLuckyNumber();
        
        if(n == 0 || n==1)
            return "Not Prime";
        
        for(int i = 2; i < n; i++){
            
            if(n%i == 0)
            return "Not Prime";
            
        }
        
        return "Prime";
    }
    
}