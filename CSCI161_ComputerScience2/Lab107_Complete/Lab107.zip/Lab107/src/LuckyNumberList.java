/**
 * LuckyNumberList creates a list of LuckyNumbers and contains
 * 3 iterators for the list.
 * @author dylca
 */


import java.util.NoSuchElementException;


public class LuckyNumberList {
    
    private LinkedPositionalList<LuckyNumber> LuckyList = null;
    
    public LuckyNumberList(){
        
        LuckyList = new LinkedPositionalList<LuckyNumber>();   
    }
    
    /**
     * isEven is passed an int and returns true if it is even 
     * and false otherwise.
     * @param n
     * @return 
     */
    public boolean isEven(int n){
        
        return (n%2 == 0);
    }
    
    /**
     * isPrime is passed an int and returns true if it is prime,
     * and false otherwise.
     * @param n
     * @return 
     */
    public boolean isPrime(int n){
        
        
        if(n == 0 || n==1)
            return false;
        
        for(int i = 2; i < n; i++){
            
            if(n%i == 0)
            return false;
            
        }
        
        return true;
    }
    
    /**
     * addLuckyNumber adds a luckynumber to the list.
     * @param Ln 
     */
    public void addLuckyNumber( LuckyNumber Ln){
        
        LuckyList.addLast(Ln);
    }
    
    /**
     * toString returns all the elements of the luckylist.
     * @return 
     */
    public String toString(){
        
        String elements = "";
        
        Iterator<LuckyNumber> listIterator = LuckyList.iterator();
                        
        while ( listIterator.hasNext() )
            elements += listIterator.next() + " ";
        
        return getClass().getName() + elements;
    }
    
    
    
   /**
    * The following code was copied from the alphabet class examples
    * and modified to fit the LuckyNumberList class.
    * 
    * edited by Dylan Carlson
    */
    
    //----- nested PositionIterator class -----
    private class PositionIterator implements Iterator<Position<LuckyNumber>>{
        private Position<LuckyNumber> cursor = LuckyList.first();   // position of the next element to report
        private Position<LuckyNumber> recent = null;               // position of last reported element
        /** Tests whether the iterator has a next object. */
        @Override
        public boolean hasNext( ) { return ( cursor != null ); }
        /** Returns the next position in the iterator. */
        @Override
        public Position<LuckyNumber> next( ) throws NoSuchElementException {
            if ( cursor == null ) throw new NoSuchElementException( "nothing left " );
            recent = cursor;
            cursor = LuckyList.after( cursor );
            return recent;
        }
        /** Removes the element returned by most recent call to next. */
        @Override
        public void remove( ) throws IllegalStateException {
            if ( recent == null ) throw new IllegalStateException( "nothing to remove" );
            LuckyList.remove( recent );         // remove from outer list
            recent = null;              // do not allow remove again until next is called
        }
    } //----- end of nested PositionIterator class -----
    
    //----- nested PositionIterable class -----
    private class PositionIterable implements Iterable<Position<LuckyNumber>>{
        @Override
        public Iterator<Position<LuckyNumber>> iterator( ) { return new PositionIterator( ); }        
    } //----- end of nested PositionIterable class -----
    
    /** Returns an iterable representation of the list's positions.
     * @return  */
    public Iterable<Position<LuckyNumber>> positions( ) {
        return new PositionIterable( );  // create a new instace of the inner class
    }
    
    
    
    private class EvenNumberIterator implements Iterator<Position<LuckyNumber>>{
        
        private Position<LuckyNumber> cursor = LuckyList.first();
        private Position<LuckyNumber> recent = null;
        
        public boolean hasNext() { return (cursor != null); }
        
        
        public Position<LuckyNumber> next() throws NoSuchElementException{
            
        
        if ( recent == null )                                                     
            {                                                                        
                while ( cursor != null && !isEven( cursor.getElement().getLuckyNumber() ) )    
                    cursor = LuckyList.after( cursor );                               
            }                                                                        
               
            if ( cursor == null ) throw new NoSuchElementException( "nothing left " );
            
            recent = cursor;
            cursor = LuckyList.after( cursor );
            
            // advance cursor to the next vowel
            
            while ( cursor != null && !isEven( cursor.getElement().getLuckyNumber()) )
                cursor = LuckyList.after( cursor );
            
            return recent;
        
        
         }
        
        public void remove( ) throws IllegalStateException {
            if ( recent == null ) throw new IllegalStateException( "nothing to remove" );
            LuckyList.remove( recent );         // remove from outer list
            recent = null;              // do not allow remove again until next is called
        }
        
    }
    
    
    //----- nested PositionIterable class -----
    private class EvenNumberIterable implements Iterable<Position<LuckyNumber>>{
        @Override
        public Iterator<Position<LuckyNumber>> iterator( ) { return new EvenNumberIterator( ); }        
    } //----- end of nested PositionIterable class -----
    
    /** Returns an iterable representation of the list's positions.
     * @return  */
    public Iterable<Position<LuckyNumber>> evenPositions( ) {
        return new EvenNumberIterable( );  // create a new instace of the inner class
    }
    
    
    
    private class PrimeNumberIterator implements Iterator<Position<LuckyNumber>>{
        
        private Position<LuckyNumber> cursor = LuckyList.first();
        private Position<LuckyNumber> recent = null;
        
        public boolean hasNext() { return (cursor != null); }
        
        public Position<LuckyNumber> next() throws NoSuchElementException{
            
        
        if ( recent == null )                                                     
            {                                                                        
                while ( cursor != null && !isPrime( cursor.getElement().getLuckyNumber() ) )    
                    cursor = LuckyList.after( cursor );                               
            }                                                                        
               
            if ( cursor == null ) throw new NoSuchElementException( "nothing left " );
            
            recent = cursor;
            cursor = LuckyList.after( cursor );
            
            // advance cursor to the next vowel
            
            while ( cursor != null && !isPrime( cursor.getElement().getLuckyNumber()) )
                cursor = LuckyList.after( cursor );
            
            return recent;
        
        
         }
        
        public void remove( ) throws IllegalStateException {
            if ( recent == null ) throw new IllegalStateException( "nothing to remove" );
            LuckyList.remove( recent );         // remove from outer list
            recent = null;              // do not allow remove again until next is called
        }
        
    }
    
    
    //----- nested PositionIterable class -----
    private class PrimeNumberIterable implements Iterable<Position<LuckyNumber>>{
        @Override
        public Iterator<Position<LuckyNumber>> iterator( ) { return new PrimeNumberIterator( ); }        
    } //----- end of nested PositionIterable class -----
    
    /** Returns an iterable representation of the list's positions.
     * @return  */
    public Iterable<Position<LuckyNumber>> primePositions( ) {
        return new PrimeNumberIterable( );  // create a new instace of the inner class
    }
    
    
}
