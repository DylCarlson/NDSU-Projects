/**
 * LuckyNumber constructs a person with a random number.
 * It has get methods, but no set methods, so they can't be changed.
 * 
 * @author Dylan Carlson
 */

import java.util.Random;

public class LuckyNumber {
    
    private String name;
    private int luckyNumber;
    Random rand = new Random();
    
    //Constructor\\
    public LuckyNumber( String name ){
        
        this.name = name;
        luckyNumber = rand.nextInt(10);
    }
    
    /**
     * getName returns the name of an instance of LuckyNumber.
     * @return 
     */
    public String getName(){
        
        return name;
    }
    
    /**
     * getLuckyNumber returns the number of an instance
     * of LuckyNumber.
     * @return 
     */
    public int getLuckyNumber(){
        
        return luckyNumber;
    }
    
    /**
     * toString returns the class name, the name,
     * and the lucky number.
     * @return 
     */
    public String toString(){
        
        return getClass().getName() + ":" + name + ":" + luckyNumber;
    }
    
    /**
     * equals is passed an object and returns true if it is equal 
     * to the lucky number and false otherwise.
     * @param o
     * @return 
     */
    public boolean equals( Object o ){
        
        if( !(o instanceof LuckyNumber) )
            return false;
        
        LuckyNumber L = (LuckyNumber) o;
        
        return name.equals( L.name )
                && luckyNumber == L.luckyNumber;
        
    }
    
}