/**
 * This Client requests a data file, reads it in, and evaluates
 * the expressions that are on each line in the file. It uses
 * the shunting yard algorithm to do this.
 * 
 * @author Dylan Carlson
 */

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Iterator;
import java.util.Scanner;

// Left for easy copy and pasting for future usage.
// C:\Users\dylca\Desktop\Lab109_Test.txt

public class Client {
    
    public static void main(String[] args) throws FileNotFoundException{
    
        Scanner scan3 = new Scanner(System.in);
        
        System.out.println("Please input a file path:  ");
        String path = scan3.nextLine();
        
        File data = new File(path);
        
        Scanner mainScan = new Scanner(data);
        
        
   while(mainScan.hasNext()){
       
       System.out.println("----New Expression----");
       
       String expression = mainScan.nextLine();
       
       
        Queue<String> postFixed = inFixedToPostFixed( stringToQueue(expression) );
        Queue<String> postFixed2 = inFixedToPostFixed( stringToQueue(expression) );
        Queue<String> tokens =  stringToQueue(expression);

        
        System.out.println("\n");
       
        System.out.println("This expression equals: " );
        
        double answer = evaluate(postFixed2);
        
     if(!(Math.abs(answer + 1) < 0.1)  && (postFixed2 != null) ){
            System.out.print(answer);
        
        
        LinkedBinaryTree<String> binaryTree = binaryExpressionTree(postFixed);
        
        
        System.out.println("\nExpression: ");
        
        while(tokens.size() != 0){
            System.out.print(tokens.dequeue());
            
        }

       System.out.println("\n\n");
        
        
        System.out.print(" Pre Order: ");
        Iterator<Position<String>> preOrderIterator = binaryTree.preorder().iterator(); 
        
        while(preOrderIterator.hasNext()){
            System.out.print( preOrderIterator.next().getElement());
            System.out.print(" ");
        }
        
        System.out.print("\n\n In Order: ");
        Iterator<Position<String>> inOrderIterator = binaryTree.inorder().iterator(); 
        
        while(inOrderIterator.hasNext()){
            System.out.print( inOrderIterator.next().getElement());
            System.out.print(" ");
        }
        
        System.out.println("\n");
        
        System.out.print(" Post Order: ");
        Iterator<Position<String>> postOrderIterator = binaryTree.postorder().iterator(); 
        
        while(postOrderIterator.hasNext()){
            System.out.print( postOrderIterator.next().getElement());
            System.out.print(" ");
        }
        
        
        System.out.println("\n\nEuler Tour: ");
        
        binaryTree.eulerTourBinary(binaryTree, binaryTree.root);
       
        
        System.out.println("\n");
        
     }
     
     
  }  
     
}
    


/**
 * stringToQueue is passed an expression from a data file, and 
 * converts it into a queue that is used later.
 * 
 * @param express
 * @return
 * @throws FileNotFoundException 
 */
 public static Queue<String> stringToQueue( String express ) throws FileNotFoundException{
   
       
       Scanner scan;
       
        scan = new Scanner( express );
        
        
        Queue<String> expression = new LinkedQueue<>();
        
     
        
        while( scan.hasNext() ){
                
         expression.enqueue( scan.next() );
        }
      
        
        return expression;
        }
 
 
 
 /** Shunting yard algorithm */
 
 
 /**
  * inFixedToPostFixed takes a queue of strings as an input
  * and returns another queue of strings, but in post fixed notation.
  * 
  * @param input
  * @return 
  */
 public static Queue<String> inFixedToPostFixed(Queue<String> input) {

     Stack<String> operators = new LinkedStack<>();
     Queue<String> postFixed = new LinkedQueue<>();
   
    
try{     
   while(input.first() != null){
         
     switch(input.first()){
         case "*" :
             while(operators.size() != 0 && (operators.top().equals("/") || operators.top().equals("*")) )
                postFixed.enqueue( operators.pop() );
             
             operators.push(input.dequeue());
             break;
         case "/" :
             while(operators.size() != 0 && operators.top().equals("/"))
                postFixed.enqueue( operators.pop() );
             
             operators.push(input.dequeue());
             break;
         case "+" :
             while(operators.size() != 0 && (operators.top().equals("*") || operators.top().equals("/") || operators.top().equals("-")) )
                postFixed.enqueue( operators.pop() );
             
             operators.push(input.dequeue());  
             break;
         case "-" :
             while(operators.size() != 0 && (operators.top().equals("*") || operators.top().equals("/") || operators.top().equals("-")) )
                postFixed.enqueue( operators.pop() );
             
             operators.push(input.dequeue());
             break;
         case "(" :
             operators.push(input.dequeue());    
             break;
         case "[" :
             operators.push(input.dequeue());
             break;
         case "{" :
             operators.push(input.dequeue());
             break;
         case ")" :
             boolean T = true;
           
           while(T == true){
               
             switch(operators.top()){
                 
                 case "(" :
                     operators.pop();
                     input.dequeue();
                     T = false;
                     break;
                 case "{" :    
                 case "[" :   
                     throw new IllegalArgumentException();
                     
                 default :
                    postFixed.enqueue(operators.pop()); 
                 
             }
           }
           break;
         case "]" :
             T = true;
           
           while(T == true){
               
             switch(operators.top()){
                 
                 case "[" :
                     operators.pop();
                     input.dequeue();
                     T = false;
                     break;
                 case "(" :    
                 case "{" :   
                     throw new IllegalArgumentException();
                     
                 default :
                    postFixed.enqueue(operators.pop()); 
                 
             }
           }
           break;
         case "}" :
           T = true;
           
           while(T == true){
               
             switch(operators.top()){
                 
                 case "{" :
                     operators.pop();
                     input.dequeue();
                     T = false;
                     break;
                 case "(" :    
                 case "[" :   
                     throw new IllegalArgumentException();
                     
                 default :
                    postFixed.enqueue(operators.pop()); 
                 
             }
           }
             
             
             break;
             
         default :
             postFixed.enqueue(input.dequeue());
           
            
     }
     
   }
     
     //Popping the rest of the operators into the queue
     
     while(operators.top() != null){
         
         postFixed.enqueue(operators.pop());
         
     }
     
 }
     catch (IllegalArgumentException | NullPointerException iae){
             
             
             return null;
             
             }

     return postFixed;
}
 
 
 /**
  * evaluate is passed the post fixed notation of an expression of one 
  * of the lines of the data file. It returns the result of the expression.
  * 
  * @param input
  * @return
  * @throws IllegalArgumentException 
  */
 public static double evaluate(Queue<String> input) throws IllegalArgumentException{
     
     Stack<Double> integers = new LinkedStack<>();
     double result = 0;
     double op1;
     double op2;
     
     
try{     
    while(input.first() != null){
       
    
     switch(input.first()){
         case "/" :
            op1 = integers.pop();
            op2 = integers.pop();
            result = op2 / op1;
            integers.push(result);
            input.dequeue();
            
             break;
         case "*" :
            op1 = integers.pop();
            op2 = integers.pop();
            result = op2 * op1;
            integers.push(result);
            input.dequeue();
             
             break;
         case "-" :
            op1 = integers.pop();
            op2 = integers.pop();
            result = op2 - op1; 
            integers.push(result);
            input.dequeue();
            
             break;
         case "+" :
            op1 = integers.pop();
            op2 = integers.pop(); 
            result = op2 + op1;
            integers.push(result);
            input.dequeue();
             
             break;
         default:
            double newEntry = Double.parseDouble(input.dequeue());
            integers.push(newEntry);
            
             
     } 
  
    }
    
        if(integers.size() == 1)
            result = integers.pop();
         else
            throw new IllegalArgumentException();
 
        
}
catch (NullPointerException npe) {
    
    System.out.println("Invalid Expression (Null pointer)");
    return -1;
}
catch (IllegalArgumentException iae) {
    
    System.out.println("Invalid Expression");
    return -1;
} 



    return result;
 } 
 
 
 /**
  * binaryExpressionTree is passed a queue of strings. It makes a 
  * binary expression tree for the given expression from post fixed
  * notation. The tree is used for the multiple traversals of the tree.
  * 
  * @param input
  * @return 
  */
 public static LinkedBinaryTree<String> binaryExpressionTree( Queue<String> input) {
     
     
     Stack<LinkedBinaryTree<String>> stackOfTrees = new LinkedStack<>();
    
     LinkedBinaryTree<String> result = new LinkedBinaryTree<>();
     
     
     
     while(input.first() != null){
         
         LinkedBinaryTree<String> sub1 = new LinkedBinaryTree<>();
         LinkedBinaryTree<String> sub2 = new LinkedBinaryTree<>();
         LinkedBinaryTree<String> sub3 = new LinkedBinaryTree<>();
        
    
     switch(input.first()){
         case "/" :
            sub1 = stackOfTrees.pop();
            sub2 = stackOfTrees.pop();
            sub3.addRoot(input.dequeue());
            sub3.attach(sub3.root(), sub2, sub1);
            
            stackOfTrees.push(sub3);
            
             break;
         case "*" :
            sub1 = stackOfTrees.pop();
            sub2 = stackOfTrees.pop();
            sub3.addRoot(input.dequeue());
            sub3.attach(sub3.root(), sub2, sub1);
            
            stackOfTrees.push(sub3);
             
             break;
         case "-" :
            sub1 = stackOfTrees.pop();
            sub2 = stackOfTrees.pop();
            sub3.addRoot(input.dequeue());
            sub3.attach(sub3.root(), sub2, sub1);
            
            stackOfTrees.push(sub3);
            
             break;
         case "+" :
            sub1 = stackOfTrees.pop();
            sub2 = stackOfTrees.pop();
            sub3.addRoot(input.dequeue());
            sub3.attach(sub3.root(), sub2, sub1);
            
            stackOfTrees.push(sub3);
             
             break;
         default:
            sub1.addRoot(input.dequeue());
            stackOfTrees.push(sub1);
        
            
      }
     
     
    }
     
     
     result = stackOfTrees.pop();
      
     return result;
 }
     
 }