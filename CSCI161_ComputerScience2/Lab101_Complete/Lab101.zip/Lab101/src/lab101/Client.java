
package lab101;

import java.util.Scanner;


/**
 *This class, Client, uses Employee, Hourly, and Salaried to make an array of
 *employees with different information and is able to store it, print it, and 
 * add a 10% raise to all the inputed Employees.
 * 
 * @version 08/29/2018
 * @author Dylan Carlson
 */


public class Client {
    
    public static void main(String[] args){
     
        
    Employee employeeList[];
    employeeList = new Employee[10];
   
    
    Scanner scan = new Scanner (System.in);
    
    System.out.println("Enter an integer value for how many Employees you wish to enter:");
    
    int numberOfEmployees = scan.nextInt();
    
   
    //Looping how ever many Employees the user chose (Less than or equal to 10).
    while ( numberOfEmployees > 0){
        numberOfEmployees--;
        
      
      System.out.println("\nIs the employee an hourly or salaried employee? (Enter 0 for Hourly and 1 for Salaried)");
       
      int employeeType = scan.nextInt();
      
      //This If statement determines the type of employee based on a 1 or 0.
      if (employeeType == 0){
       
          System.out.println("Enter their ID:  ");
          int e1 = scan.nextInt();
          
          System.out.println("Enter their name: ");
          scan.nextLine();
          String e2 = scan.nextLine();
          
          System.out.println("Enter their position: ");
          String e3 = scan.nextLine();
        
          System.out.println("Enter their hourly rate: ");
          double e4 = scan.nextDouble();
          
          Hourly h = new Hourly(e1, e2, e3, e4);
           employeeList[numberOfEmployees] = h; 
      }
      
      
      else if (employeeType == 1){
         
          System.out.println("Enter their ID:  ");
          int e1 = scan.nextInt();
          
          System.out.println("Enter their name: ");
          scan.nextLine();
          String e2 = scan.nextLine();
          
          
          System.out.println("Enter their title: ");
          String e3 = scan.nextLine();
          
          
          System.out.println("Enter their Salary: ");
          int e4 = scan.nextInt();
          
          Salaried s = new Salaried(e1, e2, e3, e4);
          employeeList[numberOfEmployees] = s;
          
      }  
      
      else 
          System.out.println("ERROR");
            
    }
  
    System.out.println("");
    
    //Printing out nicely all of the information of Employees
    for(int i=9; i>=0; i--){
        
        if ( employeeList[i] instanceof Hourly ){
       
            Hourly h1 = (Hourly) employeeList[i];
            
        System.out.println("\nEmployee ID:  " + h1.getId()); 
        System.out.println("Employee Name:  " + h1.getName());
        System.out.println("Employee Position :  " + h1.getPosition());
        System.out.println("Employee Hourly Rate:  " + h1.getHourlyRate());
       
        }
        
        else if( employeeList[i] instanceof Salaried ){
          
            Salaried s1 = (Salaried) employeeList[i];
            
        System.out.println("\nEmployee ID:  " + s1.getId()); 
        System.out.println("Employee Name:  " + s1.getName());
        System.out.println("Employee Title:  " + s1.getTitle()); 
        System.out.println("Employee Salary:  " + s1.getSalary());    
       
        }
        
        else {
            System.out.println("\nnull");
        } 
      
      }
    
    
    //Giving the Employees a 10% Raise
    for(int i=9; i>=0; i--){
        
         if ( employeeList[i] instanceof Hourly ){
             
             Hourly h2 = (Hourly) employeeList[i];
        
             h2.setHourlyRate(h2.getHourlyRate() * 1.1);
             
               }
         
         else if( employeeList[i] instanceof Salaried ){
             
             Salaried s2 = (Salaried) employeeList[i];
       
             s2.setSalary(  (int)(s2.getSalary() * 1.1)  );
             
               }
        
    }
    
    System.out.println("\n Now Printing Employees with a 10% Raise: \n");
    
    
    //Now printing all Employee Information with a 10% Raise
    
       for(int i=9; i>=0; i--){
        
        if ( employeeList[i] instanceof Hourly ){
       
            Hourly h1 = (Hourly) employeeList[i];
            
        System.out.println("\nEmployee ID:  " + h1.getId()); 
        System.out.println("Employee Name:  " + h1.getName());
        System.out.println("Employee Position :  " + h1.getPosition());
        System.out.println("Employee Hourly Rate:  " + h1.getHourlyRate());
        
        }
        
        else if( employeeList[i] instanceof Salaried ){
          
            Salaried s1 = (Salaried) employeeList[i];
            
        System.out.println("\nEmployee ID:  " + s1.getId()); 
        System.out.println("Employee Name:  " + s1.getName());
        System.out.println("Employee Title:  " + s1.getTitle()); 
        System.out.println("Employee Salary:  " + s1.getSalary());    
       
        }
     
      
      }
    
       
      //Testing equals method
      //These are test examples of an Hourly, Salaried and Employee that will be tested if they are equal.
      Hourly h1 = new Hourly(7, "Joe", "boss", 20.0);
      Salaried s1 = new Salaried(8, "Dylan", "manager", 90000);
      Employee e1 = new Employee(9, "Boy");
      
      //Testing the equals method from Hourly
      System.out.println("\nIs a Salaried Employee equal to an Hourly Employee:  " + h1.equals(s1));
       
      System.out.println("Is the Hourly constructor I created equal to itself:  " + h1.equals(h1));
      
     
      //Testing the equals method from Salaried
      System.out.println("Is an Hourly Employee equal to a Salaried Employee:  " + s1.equals(h1));
      
      System.out.println("Is the Salaried constructor I created equal to itself:  " + s1.equals(s1));
      
      
      //Testing the equals method from Employee
      System.out.println("Is a Salaried Employee equal to an Employee:  " + e1.equals(s1));
      
      System.out.println("Is the Employee constructor I created equal to itself:  " + e1.equals(e1));
        
   }
     
}