
package lab101;

/**
 * This class, Hourly, is a sub-class of Employee.
 * It contains the instance variables unique to Hourly, and getters and setters for those instances.  
 * It also contains a unique equals and toString method.
 * 
 * @version 08/29/2018
 * @author Dylan Carlson
 */


public class Hourly extends Employee {
    
   private String position;
   private double hourlyRate;
   
   
   public Hourly (int id, String name, String position, double hourlyRate){
    
    super(id, name);
    this.position = position;
    setHourlyRate( hourlyRate );
    
   }
    
   
   
        //Setters
  
   /**
    * setPosition is passed a string that is set to position.
    * @param newPosition 
    */
   public void setPosition(String newPosition){
       
       position = newPosition;
   }
    
   /**
    * setHourlyRate is passed a double that is set to hourlyRate.
    * @param newHourlyRate 
    */
   public void setHourlyRate( double newHourlyRate){
       
       hourlyRate = newHourlyRate;
       
   }
    


        //Getters
   
   /**
    * getPosition returns position to the client.
    * @return 
    */
   public String getPosition(){
       
       return position;
   }
   
   /**
    * getHourlyRate returns hourlyRate to the client.
    * @return 
    */
   public double getHourlyRate(){
       
       return hourlyRate;
   }
   
   
   
   
    /**
     * toString returns all the information in Hourly joined with Employee as a String.
     * @return 
     */
   public String toString(){
    
    return super.toString() + getClass().getName() + ":" + position + ":" + hourlyRate;
    }
   
   
   
   /**
    * The equals method tests an object to see if it is equal to the Hourly Class.
    * If it is true it passes true, and false if false.
    * @param o
    * @return 
    */
   public boolean equals( Object o){
    
    if ( !( o instanceof Hourly ))
        return false;
    
    else
     {
    Hourly e = (Hourly) o;
    
    return super.equals(o)
            
            && hourlyRate==e.hourlyRate                     
            
            &&position.equals( e.position );
     }
   }
    
}