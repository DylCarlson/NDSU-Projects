
package lab101;

/**
 * This class, Employee, is the parent class of Hourly and Salaried.
 * It contains the similar instance variables between Hourly and Salaried, and getters and setters for those instances.  
 * It also contains an equals and toString method.
 * 
 * @version 08/29/2018
 * @author Dylan Carlson
 */


public class Employee {
    
    private int id;
    private String name;
    
    
    public Employee (int id, String name) {
           
    this.id = id;
    this.name = name;
    
    }


    
    //Setters
    
/**
 * setId is passed an integer that is set to id. 
 * @param newId 
 */
public void setId( int newId ){
    
    id = newId;
    }

/**
 * setName is passed a String that is set to name.
 * @param newName 
 */
public void setName( String newName ){
    
    name = newName;
    }


    //Getters

/**
 * getId returns id to the client.
 * @return 
 */
public int getId() {
    
    return id;
    }
  
/**
 * getName returns name to the client.
 * @return 
 */
public String getName(){
    
    return name;
    }






/**
 * toString returns all the information in Employee as a String.
 * @return 
 */
public String toString(){
    
    return getClass().getName() + ":" + id + ":" + name;
    }




/**
 * The equals method tests an object to see if it is equal to the Employee Class.
 * If it is true it passes true, and false if false.
 * 
 * @param o
 * @return 
 */
public boolean equals( Object o){
    
    if ( !( o instanceof Employee ))
        return false;
    
    
     
    Employee e = (Employee) o;
    
    return id == e.id                     
            
            && name.equals( e.name );
     
    
    }


}