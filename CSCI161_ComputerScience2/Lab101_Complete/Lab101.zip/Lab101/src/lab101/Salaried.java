
package lab101;

/**
 * This class, Salaried, is a sub-class of Employee.
 * It contains the instance variables unique to Salaried, and getters and setters for those instances.  
 * It also contains a unique equals and toString method.
 * 
 * @version 08/29/2018
 * @author Dylan Carlson
 */



public class Salaried extends Employee {
    
    private String title;
    private int salary;
    
    public Salaried (int id, String name, String title, int salary){
       
        super(id, name);
        this.title = title;
        this.salary = salary;
    }
    
    
    
         //Setters
    
    /**
     * setTitle is passed a string that is set to title.
     * @param newTitle 
     */
    public void setTitle( String newTitle ){
        
        title = newTitle;
    }
    
    /**
     * setSalary is passed an integer that is set to salary.
     * @param newSalary 
     */
    public void setSalary( int newSalary){
        
        salary = newSalary;
    }
    
    
    
    
        //Getters
    
    /**
     * getTtitle returns title to the client.
     * @return 
     */
    public String getTitle(){
        
        return title;
    }
    
    /**
     * getSalary returns salary to the client.
     * @return 
     */
    public int getSalary(){
        
        return salary;
    }
    
    
    
    /**
     * toString returns all the information in Salaried joined with Employee as a String.
     * @return 
     */
    public String toString(){
    
    return super.toString() + getClass().getName() + ":" + title + ":" + salary;
    }
   
       
       
    /**
     * The equals method tests an object to see if it is equal to the Salaried Class.
     * If it is true it passes true, and false if false.
     * @param o
     * @return 
     */
   public boolean equals( Object o){
    
    if ( !( o instanceof Salaried ))
        return false;
    
    
    else
     {
    
    Salaried e = (Salaried) o;
    
    return super.equals(o) 
            
            && salary == e.salary                     
            
            && title.equals( e.title );
     }
   }
      
}
