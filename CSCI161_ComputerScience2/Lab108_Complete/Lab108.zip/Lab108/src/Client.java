/**
 * In this client I create the correct binary tree for the
 * arithmetic expression defined. It is then printed out in several ways.
 * 
 * @author Dylan Carlson
 */

import java.util.Iterator;

public class Client {

    public static void main(String[] args) {
        
        LinkedBinaryTree lbt = new LinkedBinaryTree();  // main tree
        
        LinkedBinaryTree temp1 = new LinkedBinaryTree();
        LinkedBinaryTree temp2 = new LinkedBinaryTree();
        LinkedBinaryTree temp3 = new LinkedBinaryTree();
        LinkedBinaryTree temp4 = new LinkedBinaryTree();
        LinkedBinaryTree temp5 = new LinkedBinaryTree();
        LinkedBinaryTree temp6 = new LinkedBinaryTree();
        LinkedBinaryTree temp7 = new LinkedBinaryTree();
        LinkedBinaryTree temp8 = new LinkedBinaryTree();
        LinkedBinaryTree temp9 = new LinkedBinaryTree();
        LinkedBinaryTree temp10 = new LinkedBinaryTree();
        
        
        LinkedBinaryTree sub1 = new LinkedBinaryTree();
        LinkedBinaryTree sub2 = new LinkedBinaryTree();
        LinkedBinaryTree sub3 = new LinkedBinaryTree();
        LinkedBinaryTree sub4 = new LinkedBinaryTree();
        LinkedBinaryTree sub5 = new LinkedBinaryTree();
        LinkedBinaryTree sub6 = new LinkedBinaryTree();
        LinkedBinaryTree sub7 = new LinkedBinaryTree();
        LinkedBinaryTree sub8 = new LinkedBinaryTree();
        

        temp1.addRoot("2");
        temp2.addRoot("1");
        sub1.addRoot("-");
        sub1.attach(sub1.root, temp1, temp2);
    
        temp3.addRoot("5");
        temp4.addRoot("2");
        sub2.addRoot("+");
        sub2.attach(sub2.root, temp3, temp4);
        
        sub3.addRoot("*");
        sub3.attach(sub3.root, sub2, sub1);
        
        sub4.addRoot("+");
        temp5.addRoot("2");
        temp6.addRoot("9");
        sub4.attach(sub4.root, temp5, temp6);
        
        sub5.addRoot("/");
        sub5.attach(sub5.root, sub3, sub4);

        sub6.addRoot("-");
        temp7.addRoot("7");
        temp8.addRoot("2");
        sub6.attach(sub6.root, temp7, temp8);
        
        sub7.addRoot("-");
        temp9.addRoot("1");
        sub7.attach(sub7.root, sub6, temp9);
        
        sub8.addRoot("+");
        sub8.attach(sub8.root, sub5, sub7);
        
        temp10.addRoot("8");
        lbt.addRoot("*");
        lbt.attach(lbt.root, sub8, temp10);
      
        
        lbt.eulerTourBinary(lbt, lbt.root);  

        System.out.print("\n\n In Order: ");
        Iterator<Position<String>> inOrderIterator = lbt.inorder().iterator(); 
        
        while(inOrderIterator.hasNext()){
            System.out.print( inOrderIterator.next().getElement());
            System.out.print(" ");
        }
        
        System.out.println("\n");
        
        System.out.print(" Post Order: ");
        Iterator<Position<String>> postOrderIterator = lbt.postorder().iterator(); 
        
        while(postOrderIterator.hasNext()){
            System.out.print( postOrderIterator.next().getElement());
            System.out.print(" ");
        }
        
        System.out.println("\n");
        
        System.out.print(" Breadth first Order: ");
        Iterator<Position<String>> breadthFirstIterator = lbt.breadthfirst().iterator(); 
        
        while(breadthFirstIterator.hasNext()){
            System.out.print( breadthFirstIterator.next().getElement());
            System.out.print(" ");
        }
        
        System.out.println("\n");
        
        System.out.println(" preOrder Indent: ");
        lbt.printPreorderIndent(lbt, lbt.root, 1);
        
        
        System.out.println("\n");
        
        System.out.println(" parenthesized repersentation: ");
        lbt.parenthesize(lbt, lbt.root);
         
    }
    
}
