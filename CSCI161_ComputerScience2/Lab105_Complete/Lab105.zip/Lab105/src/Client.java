
/**
 * This Client class tests all of the stack and queue
 * data structures, and ensures their correctness. Then it tests
 * the time it takes to add elements to the ArrayList, specifically 
 * when the array has to double.
 * 
 * @author dylca
 */
public class Client {
    
    public static void main (String[] args) {
        
       arrayStackTest(); 
       
       linkedStackTest();
       
       arrayQueueTest();
       
       linkedQueueTest();
       
       arrayListTest();
        
    }
    
    /**
     * This method Tests the ArrayStack
     */
    public static void arrayStackTest()  {
        Stack<Integer> S = new ArrayStack<>(4);
        
        System.out.println("Testing the ArrayStack:  ");
        
        System.out.println("Pushing 1 onto stack");
        S.push(1);
        System.out.println("Pushing 2 onto stack");
        S.push(2);
        System.out.println("Pushing 3 onto stack");
        S.push(3);
        System.out.println("Pushing 4 onto stack");
        S.push(4);
        
        System.out.println( "Size = " + S.size() );
        
        //Pushing onto a full stack
        System.out.println("Trying to push onto a full stack:  ");
        try{
        S.push(5);          
        }
        catch(IllegalStateException ise){
            System.out.println("Stack is full");
        }
        
        System.out.println("Popping off the stack:  ");
        //Popping all off
        System.out.println( S.pop() );
        System.out.println( S.pop() );
        System.out.println( S.pop() );
        System.out.println( S.pop() );
        
        System.out.println("Is the stack empty?");
        System.out.println( S.isEmpty() );
        
        //Popping an empty Stack
        System.out.println("Popping off an empty stack:  ");
        System.out.println( S.pop() );
    }

    /**
     * This method Tests the LinkedStack
     */
    public static void linkedStackTest() {
        Stack<Integer> L = new LinkedStack<>();
        
        System.out.println("\n\nTesting the Linked Stack:  ");
        
        
        System.out.println("Pushing 1 onto stack");
        L.push(1);
        System.out.println("Pushing 2 onto stack");
        L.push(2);
        System.out.println("Pushing 3 onto stack");
        L.push(3);
        System.out.println("Pushing 4 onto stack");
        L.push(4);
        
        
        System.out.println( "Size = " + L.size() );
        
        
        System.out.println("Popping off the stack:  ");
        //Popping all off
        System.out.println( L.pop() );
        System.out.println( L.pop() );
        System.out.println( L.pop() );
        System.out.println( L.pop() );
        
        System.out.println("Is the stack empty?");
        System.out.println( L.isEmpty() );
        
        //Popping an empty Stack
        System.out.println("Popping off an empty stack:  ");
        System.out.println( L.pop() );
        
        
    }
    
    /**
     * This method Tests the ArrayQueue
     */
    public static void arrayQueueTest() {
        
        Queue<Integer> Q = new ArrayQueue<>(4);
        
        System.out.println("\n\nTesting the ArrayQueue:  ");
        
        System.out.println("Entering 1 in queue");
        Q.enqueue(1);
        System.out.println("Entering 2 in queue");
        Q.enqueue(2);
        System.out.println("Entering 3 in queue");
        Q.enqueue(3);
        System.out.println("Entering 4 in queue");
        Q.enqueue(4);
        
        System.out.println( "Size = " + Q.size() );
        
        //Pushing into a full queue
        System.out.println("Trying to push into a full queue:  ");
        try{
        Q.enqueue(5);          
        }
        catch(IllegalStateException ise){
            System.out.println("Queue is full");
        }
        
        System.out.println("Deueueing all elements:  ");
       //Dequeueing all out
        System.out.println( Q.dequeue() );
        System.out.println( Q.dequeue() );
        System.out.println( Q.dequeue() );
        System.out.println( Q.dequeue() );
        
        System.out.println("Is the queue empty?");
        System.out.println( Q.isEmpty() );
        
        //Popping an empty Stack
        System.out.println("Dequeueing an empty queue:  ");
        System.out.println( Q.dequeue() );
         
    }
    
    /**
     * This method Tests the LinkedQueue
     */
    public static void linkedQueueTest() {
        
        Queue<Integer> Q = new LinkedQueue<>();
        
        System.out.println("\n\nTesting the LinkedQueue:  ");
        
        System.out.println("Entering 1 in queue");
        Q.enqueue(1);
        System.out.println("Entering 2 in queue");
        Q.enqueue(2);
        System.out.println("Entering 3 in queue");
        Q.enqueue(3);
        System.out.println("Entering 4 in queue");
        Q.enqueue(4);
        
        System.out.println( "Size = " + Q.size() );
        
        
        System.out.println("Deueueing all elements:  ");
       //Dequeueing all out
        System.out.println( Q.dequeue() );
        System.out.println( Q.dequeue() );
        System.out.println( Q.dequeue() );
        System.out.println( Q.dequeue() );
        
        System.out.println("Is the queue empty?");
        System.out.println( Q.isEmpty() );
        
        //Popping an empty Stack
        System.out.println("Dequeueing an empty queue:  ");
        System.out.println( Q.dequeue() );
         
    }
    
    /**
     * This method Tests the ArrayList and catches if 
     * there is no more available memory.
     */
    public static void arrayListTest() {
        try{
            
            System.out.println("\n\n");
        
        int k = 67108864;
        long startTime;
        long endTime;
        long elasped;
        
        System.out.println("==== Test adding "+ k +" items to the list ====");
        
        List<Boolean> L1 = new ArrayList<>();
        for (int i = 0; i < k+3; i++){
        
            
            if(i>=k-2){
                System.out.println("Size = "+ L1.size());
             startTime = System.nanoTime();
        
             L1.add(i, true);
          
             endTime = System.nanoTime();
             elasped = endTime - startTime;
               
             System.out.print("  Time = "+ elasped +" nanoseconds" );
                System.out.println("\n");
            }
             else
             L1.add(i, true);
        }
        
            System.out.println("\n\n");
        
        k *= 2;
        
        System.out.println("==== Test adding "+ k +" items to the list ====");
        
        List<Boolean> L2 = new ArrayList<>();
        for (int i = 0; i < k+3; i++){
        
            
            if(i>=k-2){
                System.out.println("Size = "+ L2.size());
             startTime = System.nanoTime();
        
             L2.add(i, true);
          
             endTime = System.nanoTime();
             elasped = endTime - startTime;
               
             System.out.print("  Time = "+ elasped +" nanoseconds" );
                System.out.println("\n");
            }
             else
             L2.add(i, true);
        }
        
        System.out.println("\n\n");
        
        k *= 2;
        
       System.out.println("==== Test adding "+ k +" items to the list ===="); 
      
        List<Boolean> L3 = new ArrayList<>();
        for (int i = 0; i < k+2; i++){
        
            
            if(i>=k-2){
                System.out.println("Size = "+ L3.size());
             startTime = System.nanoTime();
        
             L3.add(i, true);
          
             endTime = System.nanoTime();
             elasped = endTime - startTime;
               
             System.out.print("  Time = "+ elasped +" nanoseconds" );
                System.out.println("\n");
            }
             else
             L3.add(i, true);
        }
      }
        catch(OutOfMemoryError oome){
            System.out.println("Out Of memory");
        }
        
    }
   
}
