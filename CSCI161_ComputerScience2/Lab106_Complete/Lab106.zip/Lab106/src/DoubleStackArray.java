/**
 * DoubleStackArray is a generic implementation of the DoubleStack
 * interface. It uses a single array to hold both stacks. It adds blue
 * elements from the left, and red elements from the right.
 * 
 * @author Dylan Carlson
 */

public class DoubleStackArray<E> implements DoubleStack<E>{
   
    private static final int CAPACITY = 10;    
    private E[] stack;
    private int blueSize;
    private int redSize;
    private int last;                         
   
    /**
     * Default constructor for DoubleStackArray.
     * Has a default capacity of 10.
     */
    public DoubleStackArray() {
        this(CAPACITY);  
    }
    
    /**
     * Overload constructor for DoubleStackArray
     * @param capacity 
     */
    public DoubleStackArray( int capacity ){
        
       stack = (E[]) new Object[capacity];
       blueSize = 0;
       redSize = 0;
       last = capacity-1; 
    }
    
    
    /** Blue Methods **/
    
    /**
     * blueSize returns the size of the blue stack to the user.
     * @return 
     */
    public int blueSize(){
        
        return blueSize;
    }
    
    /**
     * blueIsEmpty returns true if the blue stack is empty and false otherwise.
     * @return 
     */
    public boolean blueIsEmpty(){
        
        return blueSize == 0;
    }
    
    /**
     * bluePush is passed an object and pushes it onto the top 
     * of the blue stack.
     * @param e 
     */
    public void bluePush(E e){
        
        if( (blueSize + redSize) == stack.length )
            throw new IllegalStateException("Stack is full");
        else{
            stack[blueSize++] = e;
        }     
    }
    
    /**
     * bluePop removes an element from the top of the blue stack
     * and returns the element removed.
     * @return 
     */
    public E bluePop(){
        
        if( blueIsEmpty() ){
            return null;
        }
        
        E answer = stack[--blueSize];
        
        stack[blueSize] = null;
        
        return answer;
    }
    
    /**
     * blueTop returns the element on the top of the blue stack.
     * @return 
     */
    public E blueTop(){
        
        if( blueIsEmpty() ){
            return null;
        }
        
        E answer = stack[blueSize - 1];
        
        return answer;
    }
    
    
    /** Red Methods **/
    
    
    /**
     * redSize returns the size of the red stack to the user.
     * @return 
     */
    public int redSize(){
        
        return redSize;
    }
    
    /**
     * redIsEmpty returns true if the red stack is empty and false otherwise.
     * @return 
     */
    public boolean redIsEmpty(){
        
        return redSize == 0;
    }
    
    
    /**
     * redPush is passed an object and pushes it onto the top 
     * of the red stack.
     * @param e 
     */
    public void redPush(E e){
        
        if( (blueSize + redSize) == stack.length )
            throw new IllegalStateException("Stack is full");
        else{
            redSize++;
            stack[last--] = e;
        }  
        
    }
    
    /**
     * redPop removes an element from the top of the red stack
     * and returns the element removed.
     * @return 
     */
    public E redPop(){
        
        if( redIsEmpty() ){
            return null;
        }
        
        E answer = stack[++last];
        
        stack[last] = null;
        
        redSize--;
        
        return answer;
    }
    
    /**
     * redTop returns the element on the top of the red stack.
     * @return 
     */
    public E redTop(){
        
        if( redIsEmpty() ){
            return null;
        }
        
        E answer = null;
        
        if(stack.length == last+1)
         answer = stack[last];
        else{    
         answer = stack[last + 1];
          }
        
        return answer;
    }
    
    /**
     * toString returns all the elements in each stack, the class name, 
     * and size, and the index of the last element in the array.
     * @return 
     */
    public String toString(){
        
        String blueElements = "";
        String redElements = "";
        
        for(int i = 0; i < blueSize; i++){
            blueElements = blueElements + stack[i];   
        }
        
        for(int i = (last+1); i < (blueSize + redSize); i++){
            redElements = redElements + stack[i];
        }
        
        
        return getClass().getName() + "  Blue elements: " + blueElements + "--Blue Size = " + blueSize+ "  Red Elements: "+ redElements + "--Red Size = "+ redSize + "  Last index: " + last;
    }
    
    /**
     * equals is passed an object and returns whether it is equal to 
     * the doublestack.
     * @param o
     * @return 
     */
    public boolean equals( Object o ){
        
        if(!(o instanceof DoubleStackArray))
            return false;
        
       DoubleStackArray e = (DoubleStackArray) o;
       
       
       for(int i = 0; i < blueSize; i++){
           if ( !(stack[i] == e.stack[i]) ); 
                return false;
        }
       
       for(int i = last; i > redSize; i--){
           if ( !(stack[i] == e.stack[i]) ); 
                return false;
        }
      
        return blueSize == e.blueSize
                && redSize == e.redSize;
    }
    
}