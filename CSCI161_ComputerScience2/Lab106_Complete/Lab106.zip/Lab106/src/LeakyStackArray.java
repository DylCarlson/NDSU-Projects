/**
 * LeakyStackArray is a static implementation of the LeakyStrack 
 * interface. It holds elements in an array and when it is full it
 * "leaks" or drops the last element.
 *
 * @author Dylan Carlson
 */
public class LeakyStackArray<E> implements LeakyStack<E> {
 
    public static final int CAPACITY = 10;
    private E[] stack;
    private int size;
    private int t = 0;             //top of stack
    
    /**
     * Default constructor.
     * Sets default capacity to 10.
     */
    public LeakyStackArray() { this(CAPACITY); }
    
    /**
     * Overload constructor.
     * @param capacity 
     */
    public LeakyStackArray( int capacity){
        
        stack = (E[]) new Object[capacity];
        size = 0;
    }
    
    /** Methods **/
    
    /**
     * size returns the amount of elements in the stack.
     * @return 
     */
    public int size(){
        
        return size;
    }
    
    /**
     * isEmpty returns true if the stack is empty, and false otherwise.
     * @return 
     */
    public boolean isEmpty(){
        
        return size == 0;
    }
    
    /**
     * push is passed an element and pushes it on top of the stack.
     * If full, it drops the last element in the stack, or the first added.
     * @param e 
     */
    public void push(E e){
        
        
        stack[ (t%stack.length) ] = e;
        t++;
        
        if(size != stack.length)
        size++;
    }
    
    /**
     * pop removes the top element from the stack and returns it.
     * @return 
     */
    public E pop(){
        
        if( isEmpty() ){
            return null;
        }
        
        E answer = stack[ (t-1)%stack.length ];
        t--;
        
        stack[ t%stack.length ] = null;
        
        size--;
        return answer;
    }
    
    /**
     * top returns the element at the top of the stack.
     * @return 
     */
    public E top(){
        
        if(size == 0)
            return null;
        
        E answer = stack[ (t-1)%stack.length ];
        
        return answer;
    }
    
    /**
     * toString returns all the elements in the stack, the size,
     * and the default capacity.
     * @return 
     */
    public String toString(){
    
      String elements = " ";  
        
        for(int i = 0; i<size; i++){
               
            elements  = elements + stack[i] + " ";
     }
    
    return getClass().getName() + " Default Capacity: " + CAPACITY + " Size of stack: "+ size + " Elements: "+ elements;
    }
    
    /**
     * equals is passed an Object and returns true if it is equal to 
     * the leaky stack, and false otherwise.
     * @param o
     * @return 
     */
    public boolean equals(Object o) {
    
    if( !(o instanceof LeakyStackArray) )
        return false;
    
    LeakyStackArray L = (LeakyStackArray) o;
    
    
    for(int i = 0; i<size; i++){
        
        if( !(stack[i] == L.stack[i]) ){
            return false;
        }
        
    }
    return size == L.size;
    
    }
}