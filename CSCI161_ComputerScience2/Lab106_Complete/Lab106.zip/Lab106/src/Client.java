/**
 * This client class is a thorough test of each of the stacks,
 * LeakyStack and DoubleStack.
 * 
 * @author Dylan Carlson
 */

public class Client {
    
    /**
     * The main method simply calls two methods that performs
     * multiple tests of the two stacks.
     * @param args 
     */
    public static void main(String[] args){
    
        redAndBlueTest();
        
        leakyTest();
        
    }
    
    /**
     * redAndBlueTest tests the DoubleStackArray
     */
    public static void redAndBlueTest(){
        
        
    DoubleStack<Integer> N = new DoubleStackArray<>();
    
    System.out.println("===== Testing DoubleStackArray =====");
    
    System.out.println("\nIs the blue stack empty?  "+ N.blueIsEmpty());
        System.out.println("Is the red stack empty?  "+ N.redIsEmpty());
        
        
        System.out.println("\nBlue size: "+ N.blueSize());
        System.out.println("Red size: "+ N.redSize());
        
        
        System.out.println("\nTop of Blue and Red:  ");
        System.out.println("Top of blue: "+ N.blueTop());
        System.out.println("Top of red: "+ N.redTop());
        
    
    
        System.out.println("\n----Pushing 6 onto blue----");
        System.out.println("Pushing 1 on blue:  ");
         N.bluePush(1);
         System.out.println("Pushing 2 on blue:  ");
         N.bluePush(2);
         System.out.println("Pushing 3 on blue:  ");
         N.bluePush(3);
         System.out.println("Pushing 4 on blue:  ");
         N.bluePush(4);
         System.out.println("Pushing 5 on blue:  ");
         N.bluePush(5);
         System.out.println("Pushing 6 on blue:  ");
         N.bluePush(6);
         
         System.out.println("\n----Pushing 4 onto red----");
         System.out.println("Pushing 1 on red: ");
         N.redPush(1);
         System.out.println("Pushing 2 on red: ");
         N.redPush(2);
         System.out.println("Pushing 3 on red: ");
         N.redPush(3);
         System.out.println("Pushing 4 on red: ");
         N.redPush(4);
    
         System.out.println("\n\nTesting toString:");
        System.out.println(N.toString());
        
        System.out.println("\nIs the blue stack empty?  "+ N.blueIsEmpty());
        System.out.println("Is the red stack empty?  "+ N.redIsEmpty());
        
        
        System.out.println("\nBlue size: "+ N.blueSize());
        System.out.println("Red size: "+ N.redSize());
        
        
        System.out.println("\nTop of Blue and Red:  ");
        System.out.println("Top of blue: "+ N.blueTop());
        System.out.println("Top of red: "+ N.redTop());
        
        
         System.out.println("\nPopping off each: ");
         System.out.println("\nPopping all off of blue:  ");
         System.out.println(N.bluePop());
         System.out.println(N.bluePop());
         System.out.println(N.bluePop());
         System.out.println(N.bluePop());
         System.out.println(N.bluePop());
         System.out.println(N.bluePop());
         
         System.out.println("\nPopping all off of red:  ");
         System.out.println(N.redPop());
         System.out.println(N.redPop());
         System.out.println(N.redPop());
         System.out.println(N.redPop());
    
    
         
        System.out.println("\nBlue size: "+ N.blueSize());
        System.out.println("Red size: "+ N.redSize());
        
        System.out.println("\nIs the blue stack empty?  "+ N.blueIsEmpty());
        System.out.println("Is the red stack empty?  "+ N.redIsEmpty());
        
        System.out.println("\n");
        
        System.out.println("Top of blue: "+ N.blueTop());
        System.out.println("Top of red: "+ N.redTop());
        
    }
    
    /**
     * leakyTest tests the LeakyStackArray
     */
    public static void leakyTest() {
        
        LeakyStack<Integer> L = new LeakyStackArray<>();
        
        System.out.println("\n\n===== Testing LeakyStack =====");
        
        System.out.println("\nIs the stack empty? "+ L.isEmpty() );
        
        System.out.println("\nElement on top: " + L.top() );
        
        System.out.println("\nSize of stack: " + L.size() );
        
        
        System.out.println("\nPushing 11 elements into the stack: ");
        System.out.println("pushing 1:");
        L.push(1);
        System.out.println("pushing 2:");
        L.push(2);
        System.out.println("pushing 3:");
        L.push(3);
        System.out.println("pushing 4:");
        L.push(4);
        System.out.println("pushing 5:");
        L.push(5);
        System.out.println("pushing 6:");
        L.push(6);
        System.out.println("pushing 7:");
        L.push(7);
        System.out.println("pushing 8:");
        L.push(8);
        System.out.println("pushing 9:");
        L.push(9);
        System.out.println("pushing 10:");
        L.push(10);
        System.out.println("pushing 11:");
        L.push(11);
        
        
        System.out.println("\nIs the stack empty? "+ L.isEmpty() );
        
        System.out.println("\nElement on top: " + L.top() );
        
        System.out.println("\nSize of stack: " + L.size() );
        
        
        System.out.println("\nTesting toString: \n"+ L.toString() );
        
        System.out.println("\nPopping all off");
        System.out.println(L.pop());
        System.out.println(L.pop());
        System.out.println(L.pop());
        System.out.println(L.pop());
        System.out.println(L.pop());
        System.out.println(L.pop());
        System.out.println(L.pop());
        System.out.println(L.pop());
        System.out.println(L.pop());
        System.out.println(L.pop());
        
        
        System.out.println("\nIs the stack empty? "+ L.isEmpty() );
        
        System.out.println("\nElement on top: " + L.top() );
        
        System.out.println("\nSize of stack: " + L.size() );
        
        
    }
    
}
