/**
 * LeakyStack is a generic interface that contains the methods
 * for a stack that has a unique property. Once it is full and 
 * another element is pushed onto it, it drops or "leaks" out 
 * the last element.
 * 
 * @author Dylan Carlson
 */

public interface LeakyStack<E> {
    
    
    /**
     * size returns the amount of elements in the stack.
     * @return 
     */
    int size();
    
    /**
     * isEmpty returns true if the stack is empty, and false otherwise.
     * @return 
     */
    boolean isEmpty();
    
    /**
     * push is passed an element and pushes it on top of the stack.
     * If full, it drops the last element in the stack, or the first added.
     * @param e 
     */
    void push(E e);
    
    /**
     * pop removes the top element from the stack and returns it.
     * @return 
     */
    E pop();
    
    /**
     * top returns the element at the top of the stack.
     * @return 
     */
    E top();
    
    /**
     * toString returns all the elements in the stack, the size,
     * and the default capacity.
     * @return 
     */
    String toString();
    
    /**
     * equals is passed an Object and returns true if it is equal to 
     * the leaky stack, and false otherwise.
     * @param o
     * @return 
     */
    boolean equals(Object o);
    
    
}