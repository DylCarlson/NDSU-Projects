/**
 * DoubleStack is a generic interface that contains the methods for 
 * a blue stack and a red stack.
 * 
 * @author Dylan Carlson
 */

public interface DoubleStack<E> {
    
    /** Blue Stack **/
    
    
    /**
     * blueSize returns the size of the blue stack to the user.
     * @return 
     */
    int blueSize();
    
    /**
     * blueIsEmpty returns true if the blue stack is empty and false otherwise.
     * @return 
     */
    boolean blueIsEmpty();
    
    /**
     * bluePush is passed an object and pushes it onto the top 
     * of the blue stack.
     * @param e 
     */
    void bluePush(E e);
    
    /**
     * blueTop returns the element on the top of the blue stack.
     * @return 
     */
    E blueTop();
    
    /**
     * bluePop removes an element from the top of the blue stack
     * and returns the element removed.
     * @return 
     */
    E bluePop();
    
    /** Red Stack **/
    
    
    /**
     * redSize returns the size of the red stack to the user.
     * @return 
     */
    int redSize();
    
    /**
     * redIsEmpty returns true if the red stack is empty and false otherwise.
     * @return 
     */
    boolean redIsEmpty();
    
    /**
     * redPush is passed an object and pushes it onto the top 
     * of the red stack.
     * @param e 
     */
    void redPush(E e);
    
    /**
     * redTop returns the element on the top of the red stack.
     * @return 
     */
    E redTop();
    
    /**
     * redPop removes an element from the top of the red stack
     * and returns the element removed.
     * @return 
     */
    E redPop();
    
    /**
     * toString returns all the elements in each stack, the class name, 
     * and size.
     * @return 
     */
    String toString();
    
    /**
     * equals is passed an object and returns whether it is equal to 
     * the doublestack.
     * @param o
     * @return 
     */
    boolean equals(Object o);
    
}