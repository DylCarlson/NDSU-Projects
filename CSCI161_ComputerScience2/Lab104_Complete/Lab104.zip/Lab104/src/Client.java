/**
 * This client prompts the user using a JOptionPane and calls the 
 * recursive methods from the Recursion class. It is fairly flexible
 * as to what the user enters for specific methods.
 * 
 * @author Dylan Carlson
 */
import java.io.FileNotFoundException;
import static java.lang.Double.parseDouble;
import javax.swing.JOptionPane;


public class Client {
    
    public static void main(String[] args){

    try{   
        menu();
        
    }
    catch (FileNotFoundException fnfe){
        System.out.println("File Not Found");
    }

    }
 
    
    
    /**
     * This is the main menu that the user is prompted with.
     * 
     * @throws FileNotFoundException 
     */
    public static void menu() throws FileNotFoundException{
        
        
        
        String response;
        
        String options = "A: Run method sumOfReciprocals\nB: Run Isabel's Technique\nC: Run method list\nD: Quit";
        
        response = JOptionPane.showInputDialog( null, options, "Lab104 Algorithms", 3 );        
        
        switch ( response ) 
        {
            case "a" :
            case "A" :
                System.out.println("Calling sumOfReciprocals"); 
                inputDialogA();
                break;
            case "b" :
            case "B" :
                System.out.println("Calling Isabel's Technique");  
                inputDialogB();
                break;
            case "c" :
            case "C" :    
                System.out.println("Calling list");
                inputDialogC();
                break;
            case "d" :
            case "D" :
                System.out.println("Quiting");
                break;
            default :
                System.out.println("Please try again");
                errorMessage();
                menu();
        }
    }
    
    
    /**
     * This method is called if it reaches the default case
     * of the menu swith statement.
     */
    public static void errorMessage()
    {        
        String response = "Please input a correct option";
    
        JOptionPane.showMessageDialog(null, null, response, 0);        
    }
    
    
    /**
     * This method calls sumOfReciprocals using the data
     * the user input.
     * 
     * @throws FileNotFoundException 
     */
    public static void inputDialogA( ) throws FileNotFoundException
    {
        Recursion recursive = new Recursion();
        
        String response; 
                
        response = JOptionPane.showInputDialog( null, "Please input an integer", "sumOfReciprocals", 3 );
        System.out.println("respone = " + response );
        
        double answer;
        
        answer = recursive.sumOfReciprocals( parseDouble(response) );
        System.out.println( "answer = " + answer );
        
        JOptionPane.showMessageDialog(null, answer, null, 1);
        
        
        
        menu();
    }
    
    
    /**
     * This method is very flexible. It asks for a file path,
     * and does Isabel's technique if it exists, and keeps asking until it works.
     * 
     * @throws FileNotFoundException 
     */
    public static void inputDialogB() throws FileNotFoundException{
        
        Recursion recursive = new Recursion();
        
        String response; 
                
        response = JOptionPane.showInputDialog( null, "Please input a file path", "Isabel's Technique", 3 );
        System.out.println( "response = " + response );
        
        int answer;
    try{    
        answer = recursive.loadDataFile( response );
        System.out.println( "answer = " + answer );
        
        if(answer != 0){
            
        JOptionPane.showMessageDialog(null, answer, "Total", 1);
        menu();
        }
        else{
            System.out.println("Array was not a power of 2");
            
            String options = "A: Try to enter another File \nB: Quit to menu";
            
            response = JOptionPane.showInputDialog( null, options, "The array is not a power of 2!", 2);
            
            switch ( response ){
                case "a":
                case "A":
                    System.out.println("Calling Isabel's Technique"); 
                    inputDialogB();
                    break;
                case "b":
                case "B":
                    menu();
                    break;
                default :
                    System.out.println("Nothing here");
                    errorMessage();
                    inputDialogB();
            }
            
        }
    }       
     catch (FileNotFoundException fnfe){
         
         System.out.println("File Not Found");
         
         JOptionPane.showMessageDialog(null, "Please try again", "File Not Found", 0);
         
         
         String options = "A: Try to enter another File \nB: Quit to menu";
            
            response = JOptionPane.showInputDialog( null, options, "The previous file was invalid", 2);
            
            switch ( response ){
                case "a":
                case "A":
                    System.out.println("Calling Isabel's Technique"); 
                    inputDialogB();
                    break;
                case "b":
                case "B":
                    menu();
                    break;
                default :
                    System.out.println("Nothing here");
                    errorMessage();
                    inputDialogB();
            }
     }   
        
       
    }
    
    /**
     * This method receives the input from the user and
     * applies the list method to it, and prints it in the console.
     * 
     * @throws FileNotFoundException 
     */
    public static void inputDialogC()throws FileNotFoundException{
        
        Recursion recursive = new Recursion();
        
        String response; 
                
        response = JOptionPane.showInputDialog( null, "Please input a path", "Method C", 1 );
        System.out.println("response = " + response);
        
        recursive.list( response );
        
        JOptionPane.showMessageDialog(null, "Please refer to the console", null, 1);
        
            
        menu();
    }
    
}
