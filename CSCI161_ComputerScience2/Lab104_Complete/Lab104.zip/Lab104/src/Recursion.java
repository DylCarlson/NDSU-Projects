/**
 * This class, Recursion, includes multiple recursive methods
 * used by the client. 
 * 
 * @author dylca
 */

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;



public class Recursion {
    
    
    /**
     * This method is passed a number and returns the sum
     * of reciprocals from 1 to n.
     * 
     * @param num
     * @return 
     */
    public double sumOfReciprocals(double num){
        
        if (num == 1)
            return 1.0;
        
        
        return 1.0/num + sumOfReciprocals(num-1.0);
        
    }

    /**
     * isabel() implements Isabel's technique. The goal is to
     * divide the array into two and add up the sums of the given sides,
     * and it finally returns the total sum of the array.
     * The array must be a power of 2.
     * 
     * @param a
     * @return 
     */
    public int isabel( int a[] ){

    int[] b;    
    int total;
       
       
    
    if ( a.length == 1)   //Base case
        return a[0];
    else {   
      b = new int[ (a.length/2) ];

    
    for (int i = 0; i< a.length/2; i++){
	b[i] = a[2*i] + a[2*i + 1];
    }


    total = isabel( b );     
    }
    
      
    return total;
}
   
    
   // C:\Users\dylca\Desktop\Lab104_Isabel.txt
    /**
     * loadDataFile() is used first before Isabel's technique. This is because 
     * the size must be determined, and the numbers from the data file
     * must be copied to an array if it is a power of 2. It returns the sum
     * of Isabel's technique, and 0 if it is not a power of 2.
     * 
     * 
     * @param path
     * @return
     * @throws FileNotFoundException 
     */
    public int loadDataFile( String path ) throws FileNotFoundException{
        
     
       int answer = 0;
       
       
       File data = new File( path );
        
        Scanner scan;
        scan = new Scanner( data );
        
        Scanner scan2;
        scan2 = new Scanner(data);
        
        
        
        int size = 0;
        while( scan.hasNext() ){
            
            if( scan.hasNextInt() )
            size++;
           
            
           scan.next();
        }
        
        System.out.println("Size of Array = " + size);
        
        if( powerOfTwo(size) ){
            
            int[] contents = new int[size];
        
            System.out.println("Numbers in array:  ");
            
            //data file into an array
            int i = 0;
            while( scan2.hasNext() ){
                
                if( scan2.hasNextInt() ){
                    
                contents[i] = scan2.nextInt();
                System.out.println( contents[i] );
                i++;  
              
                }
                else
                scan2.next();                    
         }
            
       answer = isabel(contents); 
       
        }
        
       return answer; 
    }
    
    
    /**
     * This method is used to determine if the array is a power
     * of 2, by taking the size and recursively determining if it is a power 
     * of 2.
     * 
     * @param n
     * @return 
     */
    public boolean powerOfTwo( int n ){
        
        boolean truth = false;
        
        
        if (n == 2){
            truth = true;
          }
        else if (n%2 == 0){
           truth = powerOfTwo(n/2);
        } 
        else if (n%2 == 1)
                truth = false;
        
        
        return truth; 
    }
    
    
    /**
     * list() prints out all of the files and directories 
     * and files within those directories of a given path.
     * 
     * @param path 
     */
    public void list( String path ){
        
      File file = new File(path);
      
      if( file.isFile() )               //Base case
            System.out.println( file );
      
      
      
      if( file.isDirectory() ){
          
          File[] a = file.listFiles();
         
          
          
          if( a != null)
          for(int i = 0; i < a.length; i++){
              
              list( a[i].getPath() );
          }
          
      }
      
    }


}