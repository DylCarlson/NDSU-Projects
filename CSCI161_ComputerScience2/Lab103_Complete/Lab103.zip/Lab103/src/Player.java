/**
 * Player is a class that holds information for a player.
 * It has the necessary accessor and manipulator methods.
 * @author dylca
 */

public class Player {
    
    private String name;
    private String positionPlayed;
    int jerseyNumber;
    
    //Overload Constructor
    public Player(String n, String p, int j){
        
        name = n;
        positionPlayed = p;
        jerseyNumber = j;
         
    }
    
    //Default Constructor
    public Player(){};
    
    
    /**
     * setName is passed a string and sets it to name.
     * @param n 
     */
    public void setName(String n){
        
        name = n;
        
    }
    
    //---Setters---\\
    
    /**
     * setPositionPlayed is passed a String and sets it 
     * to positionPlayed.
     * @param p 
     */
    public void setPositionPlayed(String p){
        
        positionPlayed = p;
        
    }
    
    
    /**
     * setJerseyNumber is passed an integer and sets 
     * it to jerseyNumber.
     * @param j 
     */
    public void setJerseyNumber(int j){
        
        jerseyNumber = j;
        
    }
    
    //---Getters---\\
    
    /**
     * getName returns name to the user.
     * @return 
     */
    public String getName(){
        
        return name;
        
    }
    
    
    /**
     * getPositionPlayed returns positionPlayed to the user.
     * @return 
     */
    public String getPositionPlayed(){
        
        return positionPlayed;
        
    }
    
    
    /**
     * getJerseyNumber returns jerseyNumber to the user.
     * @return 
     */
    public int getJerseyNumber(){
        
        return jerseyNumber;
        
    }
    
    
    /**
     * toString returns all the class variables of Player.
     * @return 
     */
    public String toString(){
        
        return getClass().getName() + ": " + name + " : " + positionPlayed + " : " + jerseyNumber;
        
    }
    
    
    /**
     * equals tests if two Players are equal to each other.
     * It returns true if they are equal, and false otherwise.
     * @param o
     * @return 
     */
    public boolean equals( Object o){
        
        if ( !( o instanceof Player ))
        return false;
    
    
    Player p = (Player) o;
    
    return name.equals( p.name )                     
            
            && positionPlayed.equals( p.positionPlayed )
            
            && jerseyNumber == p.jerseyNumber;
     
    }
   
}
