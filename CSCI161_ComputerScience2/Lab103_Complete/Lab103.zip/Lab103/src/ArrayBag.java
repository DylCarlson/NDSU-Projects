/**
 * This class, ArrayBag, implements the interface Bag. 
 * It is made generic so it can hold any type of objects
 * in an array.
 * 
 * @author Dylan Carlson
 */

import java.util.Random;


public class ArrayBag<T> implements Bag<T> {
    
    private T[] list;
    private int count;
    
    
    //Default Constructor
    public ArrayBag(){
 
        list = (T[]) new Object[50];  
        count = 0;
    }
    
    
    //Overload constructor
    public ArrayBag(int size){
        
        list = (T[]) new Object[size];   
        count = 0;
    }
   
    
    /**
     * getCurrentSize returns the count to the user.
     * @return 
     */
    public int getCurrentSize(){
        
        return count;
    }
    
    
    /**
     * isEmpty tests if the array is empty and returns either true or false.
     * @return 
     */
    public boolean isEmpty(){
        
        if( count == 0 )
            return true;
        else
            return false;   
    }
    
    
    /**
     * clear clears the array by setting everything to null.
     */
    public void clear(){
        
        for(int i = 0; i < count; i++){
            list[i] = null;
        }   
    }
    
    
    /**
     * getFrequencyOf is passed an object and returns the
     * number of times that object is in the array.
     * @param e
     * @return 
     */
    public int getFrequencyOf(T e){
        
        int frequency = 0;
        
        for(int i = 0; i < count; i++){
            
            if( list[i] == e)
                frequency++;
        }
        return frequency;
    }
    
    
    /**
     * contains is passed an object and returns true or false
     * depending if the object is in the array.
     * @param e
     * @return 
     */
    public boolean contains(T e){
        
        for(int i = 0; i < count; i++){
            
            if( list[i] == e)
                return true;
            
        }
            
        return false;
    }
    
    
    /**
     * add is passed an object and adds it to the next 
     * available position in the array.
     * @param e 
     */
       public void add(T e){
       
       if (count == list.length){ 
           
           T[] temp;
           temp = (T[]) new Object[ 2 * list.length ];
         
          //Copying list into temp  
         for(int k = 0; k<count; k++){ 
            
            temp[k] = list[k];
           }
          
         //Assigning reference temp to list
          list = temp; 
          
          //Setting temp equal to null
          temp = null;  
         }
       
     list[count] = e;
     
     count++;
    }
    
    
    /**
     * remove(T e) is passed an object and removes it from the list.
     * It returns true or false, true if the object was in the array,
     * and false otherwise.
     * @param e
     * @return 
     */
    public boolean remove(T e){
        
        for(int i = 0; i<count; i++ ){
             
            if( list[i].equals(e) ){
                 
                 for(; i < count-1; i++){     
                   
                 list[i] = list[i+1];
                 
                 
                 }
            
                 count--;
                 
                 list[count] = null;
                 
                 return true;
            
             }
        
         }
       
    return false;
    }
    
    
    /**
     * remove removes a randomly selected object and returns that object.
     * @return 
     */
    public T remove(){
        
        Random rand = new Random();
        
        int random = rand.nextInt(count); 
        
        T itemRemoved = list[random];
        
       //Removing the item at the index
       for(; random<(count-1); random++){     
                   
            list[random] = list[random+1];
        }
       
       count--;
       
       list[count] = null; 
       
       return itemRemoved;
    }
    

    /**
     * get is passed an integer and returns the object
     * at that number in the list.
     * @param index
     * @return 
     */
    public T get( int index ){
        
        
      return list[--index];
    }
   
    
    /**
     * toString returns all the objects in the array, and
     * the class name, as well as count.
     * @return 
     */
    public String toString(){      
       
       String elementsInBag = "";
       
       for(int i = 0; i<count; i++){
           
           elementsInBag = elementsInBag +  list[i].toString() + " ";
           
       }
       
       return getClass().getName() + ":" + count + ":" + elementsInBag;   
   }
    
    
    /**
     * equals is passed an object and compares it to the ArrayBag.
     * It returns true if they are equal, and false otherwise.
     * @param o
     * @return 
     */
    public boolean equals( Object o){
        
        if ( o instanceof ArrayBag ){
            
            ArrayBag e = (ArrayBag) o;
            
            if( e.count == count){
                
                for (int i = 0; i < count; i++){
                    
                    if( list[i] != e.list[i])
                        return false;
                }
                
            }
            else 
                return false;
            
        }
        else 
            return false;
      
       return true;
    }

}