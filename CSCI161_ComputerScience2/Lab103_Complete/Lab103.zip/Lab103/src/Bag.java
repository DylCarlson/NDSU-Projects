
/**
 * This interface, Bag, contains all the method signatures that 
 * are implemented into ArrayBag and LinkedBag. It is made
 * generic.
 * @author dylca
 */

public interface Bag<T> {
    
   /**
    * getCurrentSize returns the value of count.
    * @return 
    */
   int getCurrentSize();
   
   /**
    * isEmpty returns true if the list is empty, and false if it isn't.
    * @return 
    */
   boolean isEmpty();
   
   /**
    * removes all items from the bag
    */
   void clear();   
   
   /**
    * This method adds an item into the bag.
    * @param e 
    */
   void add(T e);
   
   
   /**
    * getFrequencyOf is passed an object and returns the count of
    * the specific object in the bag.
    * @param e
    * @return 
    */
   int getFrequencyOf(T e);
   
   /**
    * contains is passed an item, and if that item is found within
    * the list, it will return true, if not, false.
    * @param num
    * @return 
    */
   boolean contains(T e);
   
   /**
     * remove(E e) is passed an object, finds the first occurrence and removes it from the list,
     * and returns true if it was successful, and false otherwise.
     * @param e 
     */
   boolean remove(T e);
   
   /**
     * remove() removes a random element from the list, only if it is not empty. 
     * It returns the object removed.
     * @return
     */
   T remove();
   
   
   /**
    * toString prints all the contents of the items in the bag.
    * @return 
    */
   String toString();
   

   /**
    * equals is passed two bags and is true if they are both the same, and false otherwise
    * @param o
    * @return 
    */
    boolean equals( Object o); 
}
