/**
 * Client includes the Main method and does multiple test to assure
 * the correctness of the generic ArrayBag and LinkedBag classes. It uses 
 * these two classes to make two lists of its own, and manipulates them
 * in multiple ways.
 * 
 * @author dylca
 */

import java.util.Scanner;


public class Client {
    
    public static void main(String[] args){
        
        
        ArrayBag footballTeam = new ArrayBag(2);
        
        Scanner scan = new Scanner(System.in);
        
        
        System.out.println("How many players would you like to enter?");
        
        int numberOfPlayers = scan.nextInt();
        
        
        //Making an array of football team.
        for(int i = 0; i < numberOfPlayers; i++){
            
            Player p = new Player();
            
            
           System.out.println("\nEnter their name:  ");
           scan.nextLine();                            //Needed otherwise it skips to the second one.
           p.setName( scan.nextLine() );             
               
           System.out.println("Enter their position:  ");
           p.setPositionPlayed( scan.nextLine() );
           
           System.out.println("Enter their jersey number:  ");
           p.setJerseyNumber( scan.nextInt() );
            
           
           footballTeam.add(p);
            
        }
        
        System.out.println("\n\n"); //Formatting
        
        
        //Displaying Contents of footballTeam
        for(int i = 0; i < numberOfPlayers; i++){
            
            int h = i+1;                                 
                                            
          System.out.println( footballTeam.get(h) );
        }
        
        System.out.println("\n\n");
        
        
        //-----Removing a random player-----
        footballTeam.remove();
        
      
        //Re - Displaying of Contents of footballTeam
        for(int i = 0; i < numberOfPlayers; i++){
            
            int h = i+1;                                 
                                            
          System.out.println( footballTeam.get(h) );
        }
        
        System.out.println("\n\n"); //Formatting
        
        
        //-----Adding a new player with made up info-----
        Player newPlayer = new Player("Dylan", "QB", 44);
        footballTeam.add( newPlayer );
        
        
        //Re - Displaying of Contents of footballTeam
        for(int i = 0; i < numberOfPlayers; i++){
            
            int h = i+1;                                 
                                            
          System.out.println( footballTeam.get(h) );
        }
        
        System.out.println("\n\n"); //Formatting
        
        
        //-----Removing the new player-----
        
        footballTeam.remove( newPlayer );
        
        //Re - Displaying of Contents of footballTeam
        for(int i = 0; i < numberOfPlayers; i++){
            
            int h = i+1;                                 
                                            
          System.out.println( footballTeam.get(h) );  
        }
        
        System.out.println("\n\n"); //Formatting
        
        
        //ArrayBag of my course ids are implemented
        
        
        ArrayBag courses = new ArrayBag(5);
        
        courses.add("CSCI 161");
        courses.add("CSCI 222");
        courses.add("MATH 265");
        courses.add("EE 206");
        courses.add("STEM 303");
        
        
        //Displaying information
        for(int i = 0; i < 5; i++){
            
            int h = i+1;                                 
                                            
          System.out.println( courses.get(h) );  
        }
        
        System.out.println("\n\n"); //Formatting
        
        
        //-----Removing a random course id-----
        courses.remove();
        
        
        //Re - Displaying the infofmation for courses
        for(int i = 0; i < 5; i++){
            
            int h = i+1;                                
                                            
          System.out.println( courses.get(h) );   
        }
      
        
        //--------Start of LinkedBag Portion--------\\
       
        
        LinkedBag basketballTeam = new LinkedBag();
        
        
        System.out.println("\n\n"); //Formatting
        
        System.out.println("How many players would you like to enter?");
        
        int numberOfBasketballPlayers = scan.nextInt();
        
        
        //Making array basketball team.
        for(int i = 0; i < numberOfBasketballPlayers; i++){
            
            Player p = new Player();
            
            
           System.out.println("\nEnter their name:  ");
           scan.nextLine();                            //Needed otherwise it skips to the second one.
           p.setName( scan.nextLine() );             
               
           System.out.println("Enter their position:  ");
           p.setPositionPlayed( scan.nextLine() );
           
           System.out.println("Enter their jersey number:  ");
           p.setJerseyNumber( scan.nextInt() );
            
           
           basketballTeam.add(p);
            
        }
        
        System.out.println("\n\n"); //Formatting
        
        
        //Displaying Contents of basketballTeam
        for(int i = numberOfBasketballPlayers; i > 0; i--){
                                 
          System.out.println( basketballTeam.get(i) );
        }
        
        System.out.println("\n\n"); //Formatting
        
        
        //-----Removing a random player-----
        basketballTeam.remove();
        
        
        //Re - Displaying Contents of basketballTeam
        for(int i = numberOfBasketballPlayers; i > 0; i--){
                                      
          System.out.println( basketballTeam.get(i) );
        }
        
        System.out.println("\n\n"); //Formatting
        
        
        //-----Adding a new player with random info-----
        
        Player newPlayer2 = new Player("Dylan", "QB", 44);
        basketballTeam.add( newPlayer2 );
        
        
        //Re - Displaying Contents of basketballTeam
        for(int i = numberOfBasketballPlayers; i > 0; i--){
                                            
          System.out.println( basketballTeam.get(i) );
        }
        
        System.out.println("\n\n"); //Formatting
        
        //-----Removing the new player-----
        basketballTeam.remove( newPlayer2 );
        
        
        //Re - Displaying Contents of basketballTeam
        for(int i = numberOfBasketballPlayers; i > 0; i--){
                                          
          System.out.println( basketballTeam.get(i) );
        }
        
    }  
}
