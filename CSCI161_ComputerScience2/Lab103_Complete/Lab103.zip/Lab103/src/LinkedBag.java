/**
 * LinkedBag is essentially the same as Array Bag, except instead
 * of using an array, it uses a linked list. It creates this by creating
 * an instance of the SinglyLinkedList class.
 * It is generic and implements the Bag interface.
 * 
 * @author dylca
 */

import java.util.Random;


public class LinkedBag<T> implements Bag<T> {
    
    private SinglyLinkedList<T> list;
    private int count;
    
    
    //Default Constructor
    public LinkedBag(){
        
        list = new SinglyLinkedList<>();
        count = 0;
        
    }
    
    
    /**
     * getCurrentSize returns the count to the user. 
     * @return 
     */
    public int getCurrentSize(){
        
        return count;
    }
    
    
    /**
     * isEmpty tests if the array is empty and returns either true or false.
     * @return 
     */
    public boolean isEmpty(){
        
        if( count == 0 )
            return true;
        else
            return false;   
    }
    
    
    /**
     * clear removes all the contents out of the list.
     */
    public void clear(){
        
        for(int i = 0; i < count ; i++){
            
            list.removeFirst();
            
        }   
    }
    
    
    /**
     * getFrequencyOf is passed an object and returns the number
     * of times the object is in the list.
     * @param e
     * @return 
     */
    public int getFrequencyOf(T e){
        
        int frequency = 0;
        
        for(int i = 0; i < count; i++){
            
            
         T temp = list.removeFirst();
            
            if (temp.equals(e))
                frequency++;
            
          list.addLast(temp);
         
        }
        
        return frequency;
    }
    
    
    /**
     * contains is passed an object and returns true if the list contains
     * the object, and false otherwise.
     * @param e
     * @return 
     */
    public boolean contains(T e){
        
        boolean truth = false;
        
        for(int i = 0; i < count; i++){
            
            T temp = list.removeFirst();
            
            if( temp.equals(e))
                truth = true;
            
            list.addLast(temp);
            
        }
            
        return truth;
    }
    
    
    /**
     * add is passed an object and adds in to the end of the list.
     * @param e 
     */
    public void add(T e){
        
        
        list.addLast(e);
        count++;
    }
    
    
    /**
     * remove(T e) is passed an object and removes it from the list.
     * It returns true if it removed an object, and false otherwise.
     * @param e
     * @return 
     */
    public boolean remove(T e){
       
        boolean truth = false;
        
        for (int i = 0; i < count; i++ ){
            
            T temp = list.removeFirst();
            
            if(temp.equals(e)){
                truth = true;
                
                
            }
            else{
            list.addLast(temp);
            }     
            
        }
       
        count--;
      return truth;  
    }
    
    
    /**
     * remove randomly removes an object from the list, and fills
     * in the gap. It then returns the object that was removed.
     * @return 
     */
    public T remove(){
        
        Random rand = new Random();
        
        int random = rand.nextInt(count); 
        
        T randomRemoved = null;
        
        for (int i = 1; i < count+1; i++ ){
            
            T temp = list.removeFirst();
            
            if(i != random){
                
                
                list.addLast(temp);
            }
            else{
                randomRemoved = temp;
            }
          
        }
        
        count--;
        return randomRemoved;
    }
    
    
    /**
     * get is passed an index and returns the object that is
     * at that index.
     * @param index
     * @return 
     */
    public T get(int index){
        
        T objAtIndex = null;
        
        for (int i=1; i <= count; i++){
            
            
            T temp = list.removeFirst();
            
             if( index == i){
                 
                 objAtIndex = temp;
                 
             }
             
            list.addLast(temp);
             
        }
        
       return objAtIndex; 
    }
    
   
    /**
     * toString returns the class name, count, and all
     * of the objects in the list.
     * @return 
     */
    public String toString(){
        
        String elementsInBag = "";
        
        
        for(int i = 0; i < count; i++){
            
            elementsInBag = elementsInBag + ":" + list.first();
            
            T temp = list.removeFirst();
            
            list.addLast(temp);
            
        }
        
        return getClass().getName() + ":" + count + ":" + elementsInBag;
    }
    
    
    /**
     * equals checks to see if two bags are equal. It returns
     * true if they are, and false otherwise.
     * @param o
     * @return 
     */
    public boolean equals( Object o){
        
        boolean truth = true;
        
        if( !(o instanceof LinkedBag) )
            return false;
        
        LinkedBag e = (LinkedBag) o;
        
        if (e.count != count ) 
            return false;
        
        for (int i = 0; i < count; i++){
            
            T temp = list.removeFirst();
            
            if ( temp.equals( e.get(++i) ) )
                list.addLast(temp);
            else
                truth = false;
            
        }
        
        return truth;
    }
    
}