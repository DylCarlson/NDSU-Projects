/**
 * This is a comparator that implements the Comparator interface and
 * compares employees based on their name.
 * @author dylca
 */

public class NameComparator implements Comparator<Employee> {
    
    public int compare(Employee e1, Employee e2){
        
        return e1.getName().compareTo(e2.getName());
    }
    
}
