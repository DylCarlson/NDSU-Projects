/**
 * This is a comparator that implements the Comparator interface and
 * compares employees based on their id.
 * @author dylca
 */

public class IdComparator implements Comparator<Employee> {
    
    @Override
    public int compare(Employee e1, Employee e2){
        
       if( e1.getId() > e2.getId() ) 
        return 1;
      
       if (e1.getId() == e2.getId())
           return 0;
       
       return -1;
    }
    
}
