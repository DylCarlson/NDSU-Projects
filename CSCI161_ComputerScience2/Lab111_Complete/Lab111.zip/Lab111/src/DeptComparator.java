/**
 * This is a comparator that implements the Comparator interface and
 * compares employees based on their department.
 * @author dylca
 */

public class DeptComparator implements Comparator<Employee>{
    
    @Override
    public int compare(Employee e1, Employee e2){
        
       if( e1.getDept() > e2.getDept() ) 
        return 1;
      
       if (e1.getDept() == e2.getDept())
           return 0;
       
       return -1;
    }
    
    
}
