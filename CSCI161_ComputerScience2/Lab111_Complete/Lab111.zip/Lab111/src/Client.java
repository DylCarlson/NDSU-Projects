/**
 * This Client class creates an employee list of 100000 employees
 * and uses it to test multiple sorting algorithms.
 * @author dylca
 */

public class Client {

    
    public static void main(String[] args) {
        
        
        Employee employeeList[], temp1[], temp2[], temp3[], temp4[], temp5[];
        
        employeeList = new Employee[100000];
        
        /** Creating X amount of Employees**/
        for(int i = 0; i < 100000; i++){
            
        employeeList[i] = new Employee();
 
        }
        
        long startTime = 0;
        long endTime = 0;
        long elasped = 0;
     
        temp1 = employeeList;
        temp2 = employeeList;
        temp3 = employeeList;
        temp4 = employeeList;
        temp5 = employeeList;
        
        
    /** Comparators **/    
    IdComparator idComp = new IdComparator();    
    DeptComparator deptComp = new DeptComparator();
    HiredComparator hiredComp = new HiredComparator();
    NameComparator nameComp = new NameComparator();
    
    
    startTime = System.currentTimeMillis();
    Sort.mergeSort(temp1, nameComp);
    endTime = System.currentTimeMillis();
    elasped = endTime - startTime;
        System.out.println("Time for a Merge Sort on name: "+ elasped);
   
        
        
    startTime = System.currentTimeMillis();
    Sort.quickSort(temp2, deptComp);
    endTime = System.currentTimeMillis();
    elasped = endTime - startTime;
        System.out.println("Time for a Quick Sort on department: "+ elasped);
        
        
        
    startTime = System.currentTimeMillis();
    Sort.simpleBubbleSort(temp3, idComp);
    endTime = System.currentTimeMillis();
    elasped = endTime - startTime;
        System.out.println("Time for a Bubble Sort on id: "+ elasped);
        
        
        
    startTime = System.currentTimeMillis();
    Sort.insertionSort(temp4, nameComp);
    endTime = System.currentTimeMillis();
    elasped = endTime - startTime;
        System.out.println("Time for a Insertion Sort on name: "+ elasped);
        
        
        
    startTime = System.currentTimeMillis();
    Sort.selectionSort(temp5, idComp);
    endTime = System.currentTimeMillis();
    elasped = endTime - startTime;
        System.out.println("Time for a Selection Sort on name: "+ elasped);
    
    
    startTime = System.currentTimeMillis();   
    Sort.radixSort(employeeList, deptComp, hiredComp, nameComp );
    endTime = System.currentTimeMillis();
    elasped = endTime - startTime;
        System.out.println("Time for a Radix Sort sorted by department, hire date, and then name: "+ elasped);   
}


}