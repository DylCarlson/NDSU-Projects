
import java.util.Random;

/**
 * This Employee Class is for the Lab111 assignment and the Employee
 * is completely random.
 * @author dylca
 */

public class Employee {
    
private int id;
private int dept;
private int hired;

private String name;
private int length;

Random rand = new Random();


public Employee(){
    
    id = rand.nextInt(100000000);
    dept = rand.nextInt(5) + 1;
    hired = rand.nextInt(11) + 2008;
    
    length = rand.nextInt(6) + 5;
    
    //97 and 122
    
    name = "";
    for(int i = 0; i < length; i++){
        char a = ' ';
        
        a = (char)(rand.nextInt(26) + 97);
        
        name += a;
    }
}

public int getId(){
    return id;
}

public int getDept(){
    return dept;
}

public int getHired(){
    return hired;
}

public String getName(){
    return name;
}


public String toString(){
    
    return getClass().getName() + id + dept + hired + name;
}


public boolean equals(Object o){
    
    if(!(o instanceof Employee))
        return false;
    
    Employee e = (Employee) o;
    
    return e.id == id
            && e.dept == dept
            && e.hired == hired
            && e.name.equals(name);
    
}
    
}
