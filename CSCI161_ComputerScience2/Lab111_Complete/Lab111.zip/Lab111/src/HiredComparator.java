/**
 * This is a comparator that implements the Comparator interface and
 * compares employees based on their hire date.
 * @author dylca
 */

public class HiredComparator implements Comparator<Employee>{
    
    @Override
    public int compare(Employee e1, Employee e2){
        
       if( e1.getHired() > e2.getHired() ) 
        return 1;
      
       if (e1.getHired() == e2.getHired())
           return 0;
       
       return -1;
    }
    
    
}
